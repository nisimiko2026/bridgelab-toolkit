"""
BridgeLab Toolkit
Optional OpenAI Embedding Provider
"""

from __future__ import annotations

from typing import Any, Sequence

from .embeddings import EmbeddingVector


class OpenAIEmbeddingProvider:
    """
    Optional OpenAI adapter for the provider-neutral EmbeddingProvider contract.

    The OpenAI SDK is imported lazily so BridgeLab's core toolkit and tests do
    not require it. A compatible client may also be injected directly, which
    keeps this adapter easy to test without network access.

    The default model/dimension pair is text-embedding-3-small / 1536.
    """

    def __init__(
        self,
        *,
        model: str = "text-embedding-3-small",
        dimension: int = 1536,
        batch_size: int = 128,
        client: Any | None = None,
    ) -> None:
        if not model.strip():
            raise ValueError("embedding model must be non-empty")
        if dimension <= 0:
            raise ValueError("embedding dimension must be positive")
        if batch_size <= 0:
            raise ValueError("batch_size must be positive")

        self.model = model
        self._dimension = dimension
        self.batch_size = batch_size
        self._client = client

    @property
    def dimension(self) -> int:
        return self._dimension

    @property
    def client(self) -> Any:
        if self._client is None:
            try:
                from openai import OpenAI
            except ImportError as error:
                raise RuntimeError(
                    "OpenAI embeddings require the optional 'openai' package. "
                    "Install requirements-embeddings.txt."
                ) from error
            self._client = OpenAI()
        return self._client

    def embed_documents(
        self,
        texts: Sequence[str],
    ) -> list[EmbeddingVector]:
        values = list(texts)
        if not values:
            return []

        result: list[EmbeddingVector] = []
        for start in range(0, len(values), self.batch_size):
            batch = values[start : start + self.batch_size]
            result.extend(self._embed(batch))
        return result

    def embed_query(
        self,
        text: str,
    ) -> EmbeddingVector:
        if not text.strip():
            raise ValueError("embedding query must be non-empty")
        return self._embed([text])[0]

    def _embed(
        self,
        texts: list[str],
    ) -> list[EmbeddingVector]:
        response = self.client.embeddings.create(
            model=self.model,
            input=texts,
            dimensions=self.dimension,
            encoding_format="float",
        )

        data = list(response.data)
        if len(data) != len(texts):
            raise ValueError(
                "OpenAI embedding response count does not match input count"
            )

        # The API response includes input indices. Sort by index rather than
        # assuming response order.
        indexed = sorted(data, key=lambda item: item.index)
        expected = list(range(len(texts)))
        actual = [item.index for item in indexed]
        if actual != expected:
            raise ValueError(
                "OpenAI embedding response indices are not contiguous"
            )

        vectors: list[EmbeddingVector] = []
        for item in indexed:
            vector = tuple(float(value) for value in item.embedding)
            if len(vector) != self.dimension:
                raise ValueError(
                    "OpenAI embedding vector dimension mismatch: "
                    f"expected {self.dimension}, got {len(vector)}"
                )
            vectors.append(vector)

        return vectors
