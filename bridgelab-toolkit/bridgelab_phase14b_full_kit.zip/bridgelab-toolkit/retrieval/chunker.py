"""
BridgeLab Toolkit
Deterministic Markdown-Aware Chunker
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from hashlib import blake2b
import re

from core.models import Article

from .models import KnowledgeChunk


@dataclass(frozen=True, slots=True)
class _Fragment:
    heading_path: tuple[str, ...]
    source_key: str
    text: str
    words: int


class MarkdownChunker:
    """
    Convert canonical BridgeLab Markdown into read-only retrieval chunks.

    Markdown headings define semantic source sections. Adjacent small sections
    are then packed to avoid extremely small retrieval units. YAML front matter
    is excluded from chunk text. Fenced code blocks are kept intact whenever
    they fit within ``max_words``.

    Chunk identity depends on article id and structural source keys, not body
    wording, so ordinary prose edits inside the same section do not churn IDs.
    """

    HEADING_RE = re.compile(r"^(#{1,6})[ \t]+(.+?)[ \t]*$")
    FENCE_RE = re.compile(r"^[ \t]*(```+|~~~+)")

    def __init__(
        self,
        *,
        target_words: int = 250,
        max_words: int = 800,
    ) -> None:
        if target_words < 50:
            raise ValueError("target_words must be at least 50")
        if max_words < target_words:
            raise ValueError("max_words must be at least target_words")

        self.target_words = target_words
        self.max_words = max_words

    def chunk_article(self, article: Article) -> list[KnowledgeChunk]:
        text = article.path.read_text(encoding="utf-8")
        body = self._strip_front_matter(text)
        sections = self._sections(body)
        fragments = self._fragments(sections)
        groups = self._pack(fragments)

        chunks: list[KnowledgeChunk] = []
        for ordinal, group in enumerate(groups, start=1):
            text = "\n\n".join(
                fragment.text.strip()
                for fragment in group
                if fragment.text.strip()
            ).strip()
            if not text:
                continue

            section_paths = tuple(fragment.heading_path for fragment in group)
            heading_path = self._common_prefix(section_paths)
            source_keys = tuple(fragment.source_key for fragment in group)

            chunks.append(
                self._build_chunk(
                    article=article,
                    ordinal=ordinal,
                    heading_path=heading_path,
                    section_paths=section_paths,
                    source_keys=source_keys,
                    text=text,
                )
            )

        return chunks

    def chunk_all(self, articles: list[Article]) -> list[KnowledgeChunk]:
        chunks: list[KnowledgeChunk] = []
        for article in sorted(
            articles,
            key=lambda item: item.relative_path.as_posix(),
        ):
            chunks.extend(self.chunk_article(article))
        return chunks

    @staticmethod
    def _strip_front_matter(text: str) -> str:
        if not text.startswith("---"):
            return text

        lines = text.splitlines(keepends=True)
        if not lines or lines[0].strip() != "---":
            return text

        for index in range(1, len(lines)):
            if lines[index].strip() == "---":
                return "".join(lines[index + 1 :])

        # Malformed front matter is a validation concern. Preserve source text
        # rather than guessing where metadata ends.
        return text

    def _sections(
        self,
        body: str,
    ) -> list[tuple[tuple[str, ...], str]]:
        """
        Return atomic heading-scoped Markdown sections.

        Markdown-looking lines inside fenced code blocks are not headings.
        """
        result: list[tuple[tuple[str, ...], str]] = []
        stack: list[tuple[int, str]] = []
        current_path: tuple[str, ...] = ()
        current: list[str] = []
        fence: str | None = None

        def flush() -> None:
            if current and "".join(current).strip():
                result.append((current_path, "".join(current)))

        for line in body.splitlines(keepends=True):
            fence_match = self.FENCE_RE.match(line)
            if fence_match:
                marker = fence_match.group(1)[0]
                if fence is None:
                    fence = marker
                elif marker == fence:
                    fence = None
                current.append(line)
                continue

            match = None if fence else self.HEADING_RE.match(line.rstrip("\r\n"))
            if not match:
                current.append(line)
                continue

            flush()
            current = [line]

            level = len(match.group(1))
            title = match.group(2).strip()
            while stack and stack[-1][0] >= level:
                stack.pop()
            stack.append((level, title))
            current_path = tuple(item[1] for item in stack)

        flush()
        return result

    def _fragments(
        self,
        sections: list[tuple[tuple[str, ...], str]],
    ) -> list[_Fragment]:
        fragments: list[_Fragment] = []
        occurrences: defaultdict[tuple[str, ...], int] = defaultdict(int)

        for heading_path, section_text in sections:
            occurrences[heading_path] += 1
            occurrence = occurrences[heading_path]
            pieces = self._split_section(section_text)

            for part, piece in enumerate(pieces, start=1):
                piece = piece.strip()
                if not piece:
                    continue
                source_key = "|".join(
                    (
                        " > ".join(heading_path),
                        str(occurrence),
                        str(part),
                    )
                )
                fragments.append(
                    _Fragment(
                        heading_path=heading_path,
                        source_key=source_key,
                        text=piece,
                        words=self._word_count(piece),
                    )
                )

        return fragments

    def _pack(self, fragments: list[_Fragment]) -> list[list[_Fragment]]:
        """
        Pack adjacent fragments into useful retrieval-sized groups.

        A group is closed after it reaches target_words. max_words is a strict
        upper bound. This preserves source order without cross-article mixing.
        """
        groups: list[list[_Fragment]] = []
        current: list[_Fragment] = []
        words = 0

        for fragment in fragments:
            if current and (
                words >= self.target_words
                or words + fragment.words > self.max_words
            ):
                groups.append(current)
                current = []
                words = 0

            current.append(fragment)
            words += fragment.words

        if current:
            groups.append(current)

        return groups

    def _split_section(self, text: str) -> list[str]:
        if self._word_count(text) <= self.max_words:
            return [text]

        blocks = self._blocks(text)
        pieces: list[str] = []
        current: list[str] = []
        current_words = 0

        for block in blocks:
            words = self._word_count(block)

            if words > self.max_words:
                if current:
                    pieces.append("".join(current).rstrip())
                    current = []
                    current_words = 0
                pieces.extend(self._split_large_block(block))
                continue

            if current and current_words + words > self.max_words:
                pieces.append("".join(current).rstrip())
                current = []
                current_words = 0

            current.append(block)
            current_words += words

        if current:
            pieces.append("".join(current).rstrip())

        return pieces

    def _blocks(self, text: str) -> list[str]:
        blocks: list[str] = []
        current: list[str] = []
        fence: str | None = None

        for line in text.splitlines(keepends=True):
            match = self.FENCE_RE.match(line)
            if match:
                marker = match.group(1)[0]
                if fence is None:
                    fence = marker
                elif marker == fence:
                    fence = None
                current.append(line)
                continue

            current.append(line)
            if fence is None and not line.strip():
                blocks.append("".join(current))
                current = []

        if current:
            blocks.append("".join(current))

        return blocks

    def _split_large_block(self, block: str) -> list[str]:
        pieces: list[str] = []
        current: list[str] = []
        current_words = 0

        for line in block.splitlines(keepends=True):
            words = self._word_count(line)

            if words > self.max_words:
                if current:
                    pieces.append("".join(current).rstrip())
                    current = []
                    current_words = 0

                tokens = line.split()
                for start in range(0, len(tokens), self.max_words):
                    pieces.append(
                        " ".join(tokens[start : start + self.max_words])
                    )
                continue

            if current and current_words + words > self.max_words:
                pieces.append("".join(current).rstrip())
                current = []
                current_words = 0

            current.append(line)
            current_words += words

        if current:
            pieces.append("".join(current).rstrip())

        return pieces

    @staticmethod
    def _common_prefix(
        paths: tuple[tuple[str, ...], ...],
    ) -> tuple[str, ...]:
        if not paths:
            return ()

        prefix = list(paths[0])
        for path in paths[1:]:
            limit = min(len(prefix), len(path))
            index = 0
            while index < limit and prefix[index] == path[index]:
                index += 1
            prefix = prefix[:index]
            if not prefix:
                break

        return tuple(prefix)

    @staticmethod
    def _word_count(text: str) -> int:
        return len(text.split())

    def _build_chunk(
        self,
        *,
        article: Article,
        ordinal: int,
        heading_path: tuple[str, ...],
        section_paths: tuple[tuple[str, ...], ...],
        source_keys: tuple[str, ...],
        text: str,
    ) -> KnowledgeChunk:
        identity = "\n".join((article.id, *source_keys))
        suffix = blake2b(
            identity.encode("utf-8"),
            digest_size=10,
        ).hexdigest()

        metadata = article.metadata

        return KnowledgeChunk(
            id=f"{article.id}::chunk-{suffix}",
            article_id=article.id,
            article_path=article.relative_path.as_posix(),
            ordinal=ordinal,
            heading_path=heading_path,
            section_paths=section_paths,
            text=text,
            word_count=self._word_count(text),
            title=metadata.title,
            category=metadata.category,
            subcategory=metadata.subcategory,
            difficulty=metadata.difficulty,
            status=metadata.status,
            tags=tuple(metadata.tags),
            systems=tuple(metadata.systems),
            aliases=tuple(metadata.aliases),
            acronyms=tuple(metadata.acronyms),
            references=tuple(metadata.references),
        )
