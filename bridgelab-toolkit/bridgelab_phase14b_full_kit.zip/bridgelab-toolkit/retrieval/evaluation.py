"""
BridgeLab Toolkit
Retrieval Evaluation
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json
from typing import Protocol

from .models import SearchResult
from .search import SearchFilters


class Retriever(Protocol):
    def search(
        self,
        query: str,
        *,
        limit: int = 10,
        filters: SearchFilters | None = None,
        per_article_limit: int = 2,
    ) -> list[SearchResult]:
        ...


@dataclass(frozen=True, slots=True)
class RetrievalCase:
    query: str
    expected_articles: tuple[str, ...]
    filters: SearchFilters = SearchFilters()


@dataclass(frozen=True, slots=True)
class RetrievalCaseResult:
    query: str
    expected_articles: tuple[str, ...]
    returned_articles: tuple[str, ...]
    first_relevant_rank: int | None


@dataclass(frozen=True, slots=True)
class RetrievalMetrics:
    cases: int
    hit_at_1: float
    hit_at_3: float
    hit_at_5: float
    mrr: float


class RetrievalEvaluator:
    """
    Evaluate a retriever against deterministic query fixtures.
    """

    def __init__(self, retriever: Retriever) -> None:
        self.retriever = retriever

    def evaluate(
        self,
        cases: list[RetrievalCase],
        *,
        limit: int = 5,
        per_article_limit: int = 1,
    ) -> tuple[list[RetrievalCaseResult], RetrievalMetrics]:
        results: list[RetrievalCaseResult] = []

        for case in cases:
            found = self.retriever.search(
                case.query,
                limit=limit,
                filters=case.filters,
                per_article_limit=per_article_limit,
            )
            articles = tuple(item.chunk.article_id for item in found)
            relevant = set(case.expected_articles)
            first_rank = next(
                (
                    index
                    for index, article_id in enumerate(articles, start=1)
                    if article_id in relevant
                ),
                None,
            )
            results.append(
                RetrievalCaseResult(
                    query=case.query,
                    expected_articles=case.expected_articles,
                    returned_articles=articles,
                    first_relevant_rank=first_rank,
                )
            )

        metrics = self._metrics(results)
        return results, metrics

    @staticmethod
    def _metrics(
        results: list[RetrievalCaseResult],
    ) -> RetrievalMetrics:
        total = len(results)
        if total == 0:
            return RetrievalMetrics(
                cases=0,
                hit_at_1=0.0,
                hit_at_3=0.0,
                hit_at_5=0.0,
                mrr=0.0,
            )

        def hit(k: int) -> float:
            count = sum(
                result.first_relevant_rank is not None
                and result.first_relevant_rank <= k
                for result in results
            )
            return count / total

        reciprocal = sum(
            1.0 / result.first_relevant_rank
            for result in results
            if result.first_relevant_rank is not None
        )

        return RetrievalMetrics(
            cases=total,
            hit_at_1=hit(1),
            hit_at_3=hit(3),
            hit_at_5=hit(5),
            mrr=reciprocal / total,
        )


def load_cases(path: Path) -> list[RetrievalCase]:
    """
    Load retrieval fixtures from JSON.

    Fixture format:
    [
      {
        "query": "...",
        "expected_articles": ["path/without-md"],
        "filters": {"category": "bidding"}
      }
    ]
    """
    raw = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(raw, list):
        raise ValueError("retrieval fixture root must be a list")

    cases: list[RetrievalCase] = []
    for index, item in enumerate(raw):
        if not isinstance(item, dict):
            raise ValueError(f"fixture item {index} must be an object")

        query = item.get("query")
        expected = item.get("expected_articles")
        if not isinstance(query, str) or not query.strip():
            raise ValueError(f"fixture item {index} requires non-empty query")
        if (
            not isinstance(expected, list)
            or not expected
            or not all(isinstance(value, str) and value for value in expected)
        ):
            raise ValueError(
                f"fixture item {index} requires expected_articles strings"
            )

        filters_raw = item.get("filters", {})
        if not isinstance(filters_raw, dict):
            raise ValueError(f"fixture item {index} filters must be an object")

        allowed = {
            "category",
            "subcategory",
            "difficulty",
            "status",
            "system",
        }
        unknown = set(filters_raw) - allowed
        if unknown:
            raise ValueError(
                f"fixture item {index} has unknown filters: {sorted(unknown)}"
            )

        cases.append(
            RetrievalCase(
                query=query.strip(),
                expected_articles=tuple(expected),
                filters=SearchFilters(**filters_raw),
            )
        )

    return cases
