"""
BridgeLab Toolkit
Provider-Neutral Embedding Contracts
"""

from __future__ import annotations

from typing import Protocol, Sequence, runtime_checkable


EmbeddingVector = tuple[float, ...]


@runtime_checkable
class EmbeddingProvider(Protocol):
    """
    Minimal provider-neutral embedding contract.

    Production providers may call a local model or external service, but the
    retrieval layer depends only on this interface.
    """

    @property
    def dimension(self) -> int:
        """Return the fixed vector dimension produced by this provider."""

    def embed_documents(
        self,
        texts: Sequence[str],
    ) -> list[EmbeddingVector]:
        """Embed document texts in input order."""

    def embed_query(
        self,
        text: str,
    ) -> EmbeddingVector:
        """Embed one search query."""
