"""
BridgeLab Toolkit
Retrieval primitives.
"""

from .benchmark import (
    BenchmarkReport,
    BenchmarkResult,
    report_to_dict,
    run_benchmark,
    write_json_report,
    write_markdown_report,
)
from .chunker import MarkdownChunker
from .embeddings import EmbeddingProvider, EmbeddingVector
from .evaluation import (
    RetrievalCase,
    RetrievalCaseResult,
    RetrievalEvaluator,
    RetrievalMetrics,
    Retriever,
    load_cases,
)
from .graph_reranker import GraphReranker
from .hybrid import HybridRetriever, HybridWeights
from .models import KnowledgeChunk, SearchResult
from .openai_embeddings import OpenAIEmbeddingProvider
from .search import LexicalRetriever, SearchFilters
from .semantic import SemanticRetriever, chunk_embedding_text

__all__ = [
    "BenchmarkReport",
    "BenchmarkResult",
    "run_benchmark",
    "report_to_dict",
    "write_json_report",
    "write_markdown_report",
    "KnowledgeChunk",
    "SearchResult",
    "MarkdownChunker",
    "EmbeddingProvider",
    "EmbeddingVector",
    "OpenAIEmbeddingProvider",
    "LexicalRetriever",
    "GraphReranker",
    "HybridRetriever",
    "HybridWeights",
    "SemanticRetriever",
    "SearchFilters",
    "chunk_embedding_text",
    "Retriever",
    "RetrievalCase",
    "RetrievalCaseResult",
    "RetrievalMetrics",
    "RetrievalEvaluator",
    "load_cases",
]
