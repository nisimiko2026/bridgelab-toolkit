"""
BridgeLab Toolkit
In-Memory Semantic Retrieval
"""

from __future__ import annotations

from collections import defaultdict
import math
from typing import Iterable

from .embeddings import EmbeddingProvider, EmbeddingVector
from .models import KnowledgeChunk, SearchResult
from .search import SearchFilters, normalize_text


def chunk_embedding_text(chunk: KnowledgeChunk) -> str:
    """
    Build deterministic semantic input from canonical chunk content + metadata.
    """
    headings = " | ".join(
        " > ".join(path)
        for path in chunk.section_paths
        if path
    )
    fields = [
        chunk.title,
        headings,
        " ".join(chunk.aliases),
        " ".join(chunk.acronyms),
        " ".join(chunk.tags),
        " ".join(chunk.systems),
        chunk.category,
        chunk.subcategory,
        chunk.text,
    ]
    return "\n".join(value for value in fields if value)


class SemanticRetriever:
    """
    Provider-neutral in-memory cosine-similarity retriever.

    Chunk vectors are built once at construction. Search embeds only the query.
    No vector database, external provider, or persistence policy is assumed.
    """

    def __init__(
        self,
        chunks: list[KnowledgeChunk],
        provider: EmbeddingProvider,
    ) -> None:
        self.chunks = tuple(chunks)
        self.provider = provider

        if provider.dimension <= 0:
            raise ValueError("embedding dimension must be positive")

        texts = [chunk_embedding_text(chunk) for chunk in self.chunks]
        vectors = provider.embed_documents(texts)

        if len(vectors) != len(self.chunks):
            raise ValueError(
                "embedding provider returned a different number of vectors "
                "than input documents"
            )

        self._vectors: dict[str, EmbeddingVector] = {}
        for chunk, vector in zip(self.chunks, vectors):
            validated = self._validate_vector(vector)
            self._vectors[chunk.id] = validated

    def search(
        self,
        query: str,
        *,
        limit: int = 10,
        filters: SearchFilters | None = None,
        per_article_limit: int = 2,
    ) -> list[SearchResult]:
        if limit <= 0 or per_article_limit <= 0:
            return []
        if not query.strip():
            return []

        filters = filters or SearchFilters()
        query_vector = self._validate_vector(
            self.provider.embed_query(query)
        )
        query_norm = self._norm(query_vector)
        if query_norm == 0:
            return []

        ranked: list[SearchResult] = []
        for chunk in self.chunks:
            if not self._passes_filters(chunk, filters):
                continue

            score = self._cosine(
                query_vector,
                query_norm,
                self._vectors[chunk.id],
            )
            if score <= 0:
                continue

            ranked.append(
                SearchResult(
                    chunk=chunk,
                    score=round(score, 8),
                    matched_terms=(),
                )
            )

        ranked.sort(key=lambda item: (-item.score, item.chunk.id))

        selected: list[SearchResult] = []
        article_counts: defaultdict[str, int] = defaultdict(int)
        for result in ranked:
            article_id = result.chunk.article_id
            if article_counts[article_id] >= per_article_limit:
                continue
            selected.append(result)
            article_counts[article_id] += 1
            if len(selected) >= limit:
                break

        return selected

    def _validate_vector(
        self,
        vector: Iterable[float],
    ) -> EmbeddingVector:
        values = tuple(float(value) for value in vector)
        if len(values) != self.provider.dimension:
            raise ValueError(
                "embedding vector dimension mismatch: "
                f"expected {self.provider.dimension}, got {len(values)}"
            )
        if not all(math.isfinite(value) for value in values):
            raise ValueError("embedding vector contains non-finite values")
        return values

    @staticmethod
    def _norm(vector: EmbeddingVector) -> float:
        return math.sqrt(sum(value * value for value in vector))

    @classmethod
    def _cosine(
        cls,
        left: EmbeddingVector,
        left_norm: float,
        right: EmbeddingVector,
    ) -> float:
        right_norm = cls._norm(right)
        if left_norm == 0 or right_norm == 0:
            return 0.0
        dot = sum(a * b for a, b in zip(left, right))
        return dot / (left_norm * right_norm)

    @staticmethod
    def _passes_filters(
        chunk: KnowledgeChunk,
        filters: SearchFilters,
    ) -> bool:
        checks = (
            (chunk.category, filters.category),
            (chunk.subcategory, filters.subcategory),
            (chunk.difficulty, filters.difficulty),
            (chunk.status, filters.status),
        )
        for actual, expected in checks:
            if expected and normalize_text(actual) != normalize_text(expected):
                return False

        if filters.system:
            expected = normalize_text(filters.system)
            systems = {normalize_text(value) for value in chunk.systems}
            if expected not in systems:
                return False

        return True
