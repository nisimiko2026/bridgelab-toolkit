"""
BridgeLab Toolkit
Graph-Assisted Retrieval Reranking
"""

from __future__ import annotations

from collections import defaultdict

from .models import KnowledgeChunk, SearchResult
from .search import SearchFilters


class GraphReranker:
    """
    Conservatively rerank an existing retriever using canonical article links.

    The underlying retriever remains responsible for query relevance. The graph
    contributes only a small deterministic bonus when a candidate article is
    directly connected to highly ranked seed articles.

    Graph edges are derived exclusively from KnowledgeChunk.references, so no
    canonical Markdown is modified and no external service is required.
    """

    def __init__(
        self,
        base_retriever,
        chunks: list[KnowledgeChunk],
        *,
        seed_count: int = 5,
        candidate_multiplier: int = 5,
        graph_weight: float = 0.05,
    ) -> None:
        if seed_count <= 0:
            raise ValueError("seed_count must be positive")
        if candidate_multiplier <= 0:
            raise ValueError("candidate_multiplier must be positive")
        if graph_weight < 0:
            raise ValueError("graph_weight cannot be negative")

        self.base_retriever = base_retriever
        self.seed_count = seed_count
        self.candidate_multiplier = candidate_multiplier
        self.graph_weight = graph_weight

        self._outgoing: dict[str, set[str]] = defaultdict(set)
        self._incoming: dict[str, set[str]] = defaultdict(set)

        # References are article-level metadata repeated on every chunk. Use a
        # set to make graph construction independent of chunk count/order.
        for chunk in chunks:
            source = self._normalize_article_id(chunk.article_id)
            for raw_target in chunk.references:
                target = self._normalize_article_id(raw_target)
                if not target or target == source:
                    continue
                self._outgoing[source].add(target)
                self._incoming[target].add(source)

    @staticmethod
    def _normalize_article_id(value: str) -> str:
        value = value.strip().replace("\\", "/")
        if value.casefold().endswith(".md"):
            value = value[:-3]
        return value.casefold()

    def neighbours(self, article_id: str) -> set[str]:
        article_id = self._normalize_article_id(article_id)
        return self._outgoing.get(article_id, set()) | self._incoming.get(
            article_id,
            set(),
        )

    def search(
        self,
        query: str,
        *,
        limit: int = 10,
        filters: SearchFilters | None = None,
        per_article_limit: int = 2,
    ) -> list[SearchResult]:
        if limit <= 0 or per_article_limit <= 0:
            return []
        if not query.strip():
            return []

        candidate_limit = max(limit, limit * self.candidate_multiplier)
        candidates = self.base_retriever.search(
            query,
            limit=candidate_limit,
            filters=filters,
            per_article_limit=max(per_article_limit, candidate_limit),
        )
        if not candidates or self.graph_weight == 0:
            return self._apply_article_limit(
                candidates,
                limit=limit,
                per_article_limit=per_article_limit,
            )

        seed_articles: list[str] = []
        seen: set[str] = set()
        for result in candidates:
            article_id = self._normalize_article_id(result.chunk.article_id)
            if article_id in seen:
                continue
            seen.add(article_id)
            seed_articles.append(article_id)
            if len(seed_articles) >= self.seed_count:
                break

        # Earlier seeds contribute more. A direct relationship from/to the
        # highest-ranked seed contributes 1.0, then 1/2, 1/3, ...
        support: defaultdict[str, float] = defaultdict(float)
        for rank, seed in enumerate(seed_articles, start=1):
            contribution = 1.0 / rank
            for neighbour in self.neighbours(seed):
                support[neighbour] += contribution

        reranked: list[SearchResult] = []
        for result in candidates:
            article_id = self._normalize_article_id(result.chunk.article_id)
            bonus = self.graph_weight * support.get(article_id, 0.0)
            reranked.append(
                SearchResult(
                    chunk=result.chunk,
                    score=round(result.score + bonus, 8),
                    matched_terms=result.matched_terms,
                )
            )

        reranked.sort(key=lambda item: (-item.score, item.chunk.id))
        return self._apply_article_limit(
            reranked,
            limit=limit,
            per_article_limit=per_article_limit,
        )

    @staticmethod
    def _apply_article_limit(
        results: list[SearchResult],
        *,
        limit: int,
        per_article_limit: int,
    ) -> list[SearchResult]:
        selected: list[SearchResult] = []
        counts: defaultdict[str, int] = defaultdict(int)

        for result in results:
            article_id = result.chunk.article_id
            if counts[article_id] >= per_article_limit:
                continue
            selected.append(result)
            counts[article_id] += 1
            if len(selected) >= limit:
                break

        return selected
