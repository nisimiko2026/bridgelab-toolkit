"""
BridgeLab Toolkit
Retrieval Benchmark Runner
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Callable
import json

from core.repository import Repository

from .chunker import MarkdownChunker
from .embeddings import EmbeddingProvider
from .evaluation import RetrievalEvaluator, RetrievalMetrics, load_cases
from .hybrid import HybridRetriever
from .search import LexicalRetriever
from .semantic import SemanticRetriever


@dataclass(frozen=True, slots=True)
class BenchmarkResult:
    name: str
    metrics: RetrievalMetrics


@dataclass(frozen=True, slots=True)
class BenchmarkReport:
    cases: int
    chunks: int
    lexical: BenchmarkResult
    semantic: BenchmarkResult | None
    hybrid: BenchmarkResult | None


def _evaluate(name: str, retriever, cases) -> BenchmarkResult:
    _, metrics = RetrievalEvaluator(retriever).evaluate(
        cases,
        limit=5,
        per_article_limit=1,
    )
    return BenchmarkResult(name=name, metrics=metrics)


def run_benchmark(
    *,
    knowledge_root: Path,
    fixture_path: Path,
    embedding_provider: EmbeddingProvider | None = None,
    target_words: int = 250,
    max_words: int = 800,
) -> BenchmarkReport:
    """
    Run one reproducible BridgeLab retrieval benchmark.

    Lexical retrieval always runs. Semantic and hybrid retrieval run only when
    an embedding provider is supplied.
    """
    articles = Repository(knowledge_root).build()
    chunks = MarkdownChunker(
        target_words=target_words,
        max_words=max_words,
    ).chunk_all(articles)
    cases = load_cases(fixture_path)

    lexical_retriever = LexicalRetriever(chunks)
    lexical = _evaluate("lexical", lexical_retriever, cases)

    semantic = None
    hybrid = None
    if embedding_provider is not None:
        semantic_retriever = SemanticRetriever(chunks, embedding_provider)
        semantic = _evaluate("semantic", semantic_retriever, cases)

        hybrid_retriever = HybridRetriever(
            lexical_retriever,
            semantic_retriever,
        )
        hybrid = _evaluate("hybrid", hybrid_retriever, cases)

    return BenchmarkReport(
        cases=len(cases),
        chunks=len(chunks),
        lexical=lexical,
        semantic=semantic,
        hybrid=hybrid,
    )


def report_to_dict(report: BenchmarkReport) -> dict:
    def result(value: BenchmarkResult | None):
        if value is None:
            return None
        return {
            "name": value.name,
            "metrics": asdict(value.metrics),
        }

    return {
        "cases": report.cases,
        "chunks": report.chunks,
        "lexical": result(report.lexical),
        "semantic": result(report.semantic),
        "hybrid": result(report.hybrid),
    }


def write_json_report(report: BenchmarkReport, path: Path) -> None:
    path.write_text(
        json.dumps(report_to_dict(report), indent=2),
        encoding="utf-8",
    )


def write_markdown_report(report: BenchmarkReport, path: Path) -> None:
    rows = []

    def add(result: BenchmarkResult | None) -> None:
        if result is None:
            return
        metrics = result.metrics
        rows.append(
            f"| {result.name} | {metrics.hit_at_1:.3f} | "
            f"{metrics.hit_at_3:.3f} | {metrics.hit_at_5:.3f} | "
            f"{metrics.mrr:.3f} |"
        )

    add(report.lexical)
    add(report.semantic)
    add(report.hybrid)

    provider_note = (
        "Semantic and hybrid modes were not run because no embedding provider "
        "was supplied."
        if report.semantic is None
        else "Lexical, semantic, and hybrid modes used the same fixture set."
    )

    text = "\n".join(
        [
            "# BridgeLab Retrieval Benchmark",
            "",
            f"- Cases: **{report.cases}**",
            f"- Chunks: **{report.chunks}**",
            f"- {provider_note}",
            "",
            "| Retriever | Hit@1 | Hit@3 | Hit@5 | MRR |",
            "|---|---:|---:|---:|---:|",
            *rows,
            "",
        ]
    )
    path.write_text(text, encoding="utf-8")
