"""
BridgeLab Toolkit
Hybrid Retrieval via Reciprocal Rank Fusion
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass

from .models import SearchResult
from .search import SearchFilters


@dataclass(frozen=True, slots=True)
class HybridWeights:
    """
    Relative source weights for rank fusion.
    """

    lexical: float = 1.0
    semantic: float = 1.0


class HybridRetriever:
    """
    Combine lexical and semantic rankings using Reciprocal Rank Fusion (RRF).

    The component depends only on the common ``search`` contract. It therefore
    works with any lexical or semantic implementation that returns SearchResult
    objects and supports the standard BridgeLab retrieval arguments.
    """

    def __init__(
        self,
        lexical_retriever,
        semantic_retriever,
        *,
        rrf_k: int = 60,
        weights: HybridWeights | None = None,
        candidate_multiplier: int = 4,
    ) -> None:
        if rrf_k <= 0:
            raise ValueError("rrf_k must be positive")
        if candidate_multiplier <= 0:
            raise ValueError("candidate_multiplier must be positive")

        self.lexical_retriever = lexical_retriever
        self.semantic_retriever = semantic_retriever
        self.rrf_k = rrf_k
        self.weights = weights or HybridWeights()
        self.candidate_multiplier = candidate_multiplier

        if self.weights.lexical < 0 or self.weights.semantic < 0:
            raise ValueError("hybrid weights cannot be negative")
        if self.weights.lexical == 0 and self.weights.semantic == 0:
            raise ValueError("at least one hybrid weight must be positive")

    def search(
        self,
        query: str,
        *,
        limit: int = 10,
        filters: SearchFilters | None = None,
        per_article_limit: int = 2,
    ) -> list[SearchResult]:
        if limit <= 0 or per_article_limit <= 0:
            return []
        if not query.strip():
            return []

        candidate_limit = max(limit, limit * self.candidate_multiplier)

        lexical = self.lexical_retriever.search(
            query,
            limit=candidate_limit,
            filters=filters,
            per_article_limit=max(per_article_limit, candidate_limit),
        )
        semantic = self.semantic_retriever.search(
            query,
            limit=candidate_limit,
            filters=filters,
            per_article_limit=max(per_article_limit, candidate_limit),
        )

        by_chunk = {}
        scores: defaultdict[str, float] = defaultdict(float)

        for weight, results in (
            (self.weights.lexical, lexical),
            (self.weights.semantic, semantic),
        ):
            if weight == 0:
                continue
            for rank, result in enumerate(results, start=1):
                chunk_id = result.chunk.id
                by_chunk[chunk_id] = result.chunk
                scores[chunk_id] += weight / (self.rrf_k + rank)

        fused = [
            SearchResult(
                chunk=by_chunk[chunk_id],
                score=round(score, 8),
                matched_terms=(),
            )
            for chunk_id, score in scores.items()
            if score > 0
        ]
        fused.sort(key=lambda item: (-item.score, item.chunk.id))

        selected: list[SearchResult] = []
        article_counts: defaultdict[str, int] = defaultdict(int)
        for result in fused:
            article_id = result.chunk.article_id
            if article_counts[article_id] >= per_article_limit:
                continue
            selected.append(result)
            article_counts[article_id] += 1
            if len(selected) >= limit:
                break

        return selected
