"""
BridgeLab Toolkit
Retrieval Data Models
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class KnowledgeChunk:
    """
    Read-only retrieval unit derived from one canonical Markdown article.

    A chunk may contain several adjacent Markdown sections. ``heading_path`` is
    their common heading ancestry; ``section_paths`` records each source
    section represented in the chunk.
    """

    id: str
    article_id: str
    article_path: str
    ordinal: int

    heading_path: tuple[str, ...]
    section_paths: tuple[tuple[str, ...], ...]

    text: str
    word_count: int

    title: str
    category: str
    subcategory: str
    difficulty: str
    status: str

    tags: tuple[str, ...]
    systems: tuple[str, ...]
    aliases: tuple[str, ...]
    acronyms: tuple[str, ...]
    references: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class SearchResult:
    """
    One deterministic retrieval result.
    """

    chunk: KnowledgeChunk
    score: float
    matched_terms: tuple[str, ...]
