"""
BridgeLab Toolkit
Deterministic Lexical + Metadata Retrieval
"""

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
import math
import re
import unicodedata

from .models import KnowledgeChunk, SearchResult


_TOKEN_RE = re.compile(r"[\w]+|[♣♦♥♠]", re.UNICODE)


def normalize_text(value: str) -> str:
    """
    Canonical retrieval normalization without external NLP dependencies.
    """
    value = unicodedata.normalize("NFKC", value).casefold()
    value = value.replace("no trump", "notrump")
    return " ".join(_TOKEN_RE.findall(value))


def tokenize(value: str) -> tuple[str, ...]:
    normalized = normalize_text(value)
    return tuple(normalized.split()) if normalized else ()


@dataclass(frozen=True, slots=True)
class SearchFilters:
    """
    Optional metadata constraints. Empty values mean no constraint.
    """

    category: str = ""
    subcategory: str = ""
    difficulty: str = ""
    status: str = ""
    system: str = ""


class LexicalRetriever:
    """
    Small dependency-free BM25-style retriever over KnowledgeChunk objects.

    Scoring combines:
    - BM25-style body relevance,
    - exact/term matches in title and heading paths,
    - aliases/acronyms/tags/systems metadata,
    - deterministic metadata filters.

    Results are sorted by descending score and then stable chunk id.
    """

    def __init__(
        self,
        chunks: list[KnowledgeChunk],
        *,
        k1: float = 1.5,
        b: float = 0.75,
    ) -> None:
        if k1 <= 0:
            raise ValueError("k1 must be positive")
        if not 0 <= b <= 1:
            raise ValueError("b must be between 0 and 1")

        self.chunks = tuple(chunks)
        self.k1 = k1
        self.b = b

        self._body_tokens: dict[str, tuple[str, ...]] = {}
        self._body_tf: dict[str, Counter[str]] = {}
        self._field_tokens: dict[str, dict[str, tuple[str, ...]]] = {}
        self._document_frequency: Counter[str] = Counter()

        total_length = 0

        for chunk in self.chunks:
            body_tokens = tokenize(chunk.text)
            self._body_tokens[chunk.id] = body_tokens
            self._body_tf[chunk.id] = Counter(body_tokens)
            total_length += len(body_tokens)

            unique = set(body_tokens)
            for term in unique:
                self._document_frequency[term] += 1

            heading_text = " ".join(
                heading
                for path in chunk.section_paths
                for heading in path
            )
            self._field_tokens[chunk.id] = {
                "title": tokenize(chunk.title),
                "heading": tokenize(heading_text),
                "alias": tokenize(" ".join(chunk.aliases)),
                "acronym": tokenize(" ".join(chunk.acronyms)),
                "tag": tokenize(" ".join(chunk.tags)),
                "system": tokenize(" ".join(chunk.systems)),
                "category": tokenize(chunk.category),
                "subcategory": tokenize(chunk.subcategory),
            }

        self.average_length = (
            total_length / len(self.chunks)
            if self.chunks
            else 0.0
        )

    def search(
        self,
        query: str,
        *,
        limit: int = 10,
        filters: SearchFilters | None = None,
        per_article_limit: int = 2,
    ) -> list[SearchResult]:
        if limit <= 0:
            return []
        if per_article_limit <= 0:
            return []

        query_tokens = tokenize(query)
        if not query_tokens:
            return []

        filters = filters or SearchFilters()
        normalized_phrase = normalize_text(query)
        results: list[SearchResult] = []

        for chunk in self.chunks:
            if not self._passes_filters(chunk, filters):
                continue

            score, matched = self._score_chunk(
                chunk,
                query_tokens,
                normalized_phrase,
            )
            if score <= 0:
                continue

            results.append(
                SearchResult(
                    chunk=chunk,
                    score=round(score, 8),
                    matched_terms=tuple(sorted(matched)),
                )
            )

        results.sort(key=lambda item: (-item.score, item.chunk.id))

        selected: list[SearchResult] = []
        article_counts: defaultdict[str, int] = defaultdict(int)
        for result in results:
            article_id = result.chunk.article_id
            if article_counts[article_id] >= per_article_limit:
                continue
            selected.append(result)
            article_counts[article_id] += 1
            if len(selected) >= limit:
                break

        return selected

    def _score_chunk(
        self,
        chunk: KnowledgeChunk,
        query_tokens: tuple[str, ...],
        normalized_phrase: str,
    ) -> tuple[float, set[str]]:
        tf = self._body_tf[chunk.id]
        body_len = len(self._body_tokens[chunk.id])
        fields = self._field_tokens[chunk.id]

        score = 0.0
        matched: set[str] = set()

        for term in query_tokens:
            term_score = self._bm25(term, tf[term], body_len)
            if term_score > 0:
                score += term_score
                matched.add(term)

            # Metadata/structural field boosts are intentionally simple and
            # transparent so later evaluation can tune them deterministically.
            for field, weight in (
                ("title", 4.0),
                ("heading", 2.5),
                ("alias", 3.0),
                ("acronym", 3.0),
                ("system", 2.5),
                ("tag", 1.5),
                ("category", 0.75),
                ("subcategory", 1.0),
            ):
                count = fields[field].count(term)
                if count:
                    score += weight * min(count, 3)
                    matched.add(term)

        if normalized_phrase:
            title = normalize_text(chunk.title)
            headings = normalize_text(
                " ".join(
                    heading
                    for path in chunk.section_paths
                    for heading in path
                )
            )
            aliases = normalize_text(" ".join(chunk.aliases))
            acronyms = normalize_text(" ".join(chunk.acronyms))

            if normalized_phrase == title:
                score += 12.0
            elif normalized_phrase in title:
                score += 8.0

            if normalized_phrase in headings:
                score += 5.0
            if normalized_phrase and normalized_phrase in aliases:
                score += 6.0
            if normalized_phrase and normalized_phrase in acronyms:
                score += 6.0

        # Prefer chunks matching more distinct query terms.
        if query_tokens:
            coverage = len(matched) / len(set(query_tokens))
            score *= 0.75 + 0.25 * coverage

        return score, matched

    def _bm25(self, term: str, frequency: int, body_len: int) -> float:
        if frequency <= 0 or not self.chunks:
            return 0.0

        n = len(self.chunks)
        df = self._document_frequency[term]
        idf = math.log(1.0 + (n - df + 0.5) / (df + 0.5))

        average = self.average_length or 1.0
        denominator = frequency + self.k1 * (
            1.0 - self.b + self.b * body_len / average
        )
        return idf * (frequency * (self.k1 + 1.0)) / denominator

    @staticmethod
    def _passes_filters(
        chunk: KnowledgeChunk,
        filters: SearchFilters,
    ) -> bool:
        checks = (
            (chunk.category, filters.category),
            (chunk.subcategory, filters.subcategory),
            (chunk.difficulty, filters.difficulty),
            (chunk.status, filters.status),
        )
        for actual, expected in checks:
            if expected and normalize_text(actual) != normalize_text(expected):
                return False

        if filters.system:
            expected = normalize_text(filters.system)
            systems = {normalize_text(value) for value in chunk.systems}
            if expected not in systems:
                return False

        return True
