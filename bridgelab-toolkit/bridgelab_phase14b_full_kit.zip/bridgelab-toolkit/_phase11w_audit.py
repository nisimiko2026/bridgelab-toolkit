
import collections,json
from pathlib import Path
from bridge import run_sayc_coverage_benchmark, Suit, Seat, evaluate_hand

report=run_sayc_coverage_benchmark(start_seed=1,count=10000)
targets=[case for case in report.batch.cases if case.result.stop_reason.value=="no-recommendation" and case.result.final_auction=="1C P 1S P"]

cats=collections.Counter(); hcp=collections.Counter(); details=[]
for case in targets:
 ev=evaluate_hand(case.deal.hand(Seat.NORTH))
 S=ev.length(Suit.SPADES);H=ev.length(Suit.HEARTS);D=ev.length(Suit.DIAMONDS);C=ev.length(Suit.CLUBS)
 x={"seed":case.deal.seed,"hcp":ev.hcp,"S":S,"H":H,"D":D,"C":C,"balanced":ev.is_balanced}
 hcp[ev.hcp]+=1
 # Why existing rule set fails, in priority order.
 if S>=4: cat="unexpected_spade_support"
 elif H>=4:
   if ev.hcp<16: cat="heart_second_suit_below_reverse_16"
   elif C<=H: cat="heart_reverse_clubs_not_longer"
   else: cat="unexpected_qualifying_reverse"
 elif D>=4: cat="unexpected_diamond_second_suit"
 elif ev.is_balanced and 12<=ev.hcp<=14: cat="unexpected_1nt"
 elif ev.is_balanced and 18<=ev.hcp<=19: cat="unexpected_2nt"
 elif C>=6: cat="unexpected_6club_rebid"
 else: cat="no_existing_deterministic_slice"
 cats[cat]+=1; x["blocker_family"]=cat; details.append(x)

data={"phase":"11W","sample":{"start_seed":1,"count":10000,"target_count":len(targets)},
"blocker_families":dict(cats),"hcp_distribution":dict(sorted(hcp.items())),"details":details}
Path("/mnt/data/bridgelab_phase11w_1c1s_opener_residual_audit.json").write_text(json.dumps(data,indent=2),encoding="utf-8")
print(json.dumps({k:v for k,v in data.items() if k!="details"},indent=2))
