from __future__ import annotations

import unittest

from retrieval.graph_reranker import GraphReranker
from retrieval.models import KnowledgeChunk, SearchResult


def chunk(
    chunk_id: str,
    article_id: str,
    *,
    references: tuple[str, ...] = (),
) -> KnowledgeChunk:
    return KnowledgeChunk(
        id=chunk_id,
        article_id=article_id,
        article_path=f"{article_id}.md",
        ordinal=0,
        heading_path=(),
        section_paths=(),
        text=article_id,
        word_count=1,
        title=article_id,
        category="play",
        subcategory="declarer-play",
        difficulty="Intermediate",
        status="Draft",
        tags=(),
        systems=(),
        aliases=(),
        acronyms=(),
        references=references,
    )


class StaticRetriever:
    def __init__(self, results):
        self.results = results
        self.calls = []

    def search(
        self,
        query,
        *,
        limit=10,
        filters=None,
        per_article_limit=2,
    ):
        self.calls.append((query, limit, filters, per_article_limit))
        return list(self.results[:limit])


class GraphRerankerTests(unittest.TestCase):
    def test_connected_candidate_receives_bonus(self) -> None:
        a = chunk("a0", "a", references=("c",))
        b = chunk("b0", "b")
        c = chunk("c0", "c")

        base = StaticRetriever(
            [
                SearchResult(a, 10.0, ("x",)),
                SearchResult(b, 9.95, ("x",)),
                SearchResult(c, 9.90, ("x",)),
            ]
        )
        reranker = GraphReranker(
            base,
            [a, b, c],
            seed_count=1,
            graph_weight=0.06,
        )

        results = reranker.search("x", limit=3, per_article_limit=1)

        self.assertEqual(
            [result.chunk.article_id for result in results],
            ["a", "c", "b"],
        )
        self.assertEqual(results[1].matched_terms, ("x",))

    def test_incoming_links_are_also_graph_support(self) -> None:
        a = chunk("a0", "a")
        b = chunk("b0", "b", references=("a.md",))

        reranker = GraphReranker(
            StaticRetriever(
                [
                    SearchResult(a, 5.0, ()),
                    SearchResult(b, 4.9, ()),
                ]
            ),
            [a, b],
            seed_count=1,
            graph_weight=0.06,
        )

        self.assertEqual(reranker.neighbours("a"), {"b"})
        results = reranker.search("query", limit=2, per_article_limit=1)
        self.assertEqual(results[1].chunk.article_id, "b")
        self.assertGreater(results[1].score, 4.9)

    def test_zero_graph_weight_preserves_base_order(self) -> None:
        a = chunk("a0", "a", references=("c",))
        b = chunk("b0", "b")
        c = chunk("c0", "c")
        base_results = [
            SearchResult(a, 3.0, ()),
            SearchResult(b, 2.0, ()),
            SearchResult(c, 1.0, ()),
        ]

        reranker = GraphReranker(
            StaticRetriever(base_results),
            [a, b, c],
            graph_weight=0,
        )
        results = reranker.search("q", limit=3, per_article_limit=1)

        self.assertEqual(
            [result.chunk.article_id for result in results],
            ["a", "b", "c"],
        )

    def test_per_article_limit_is_applied_after_reranking(self) -> None:
        a1 = chunk("a1", "a")
        a2 = chunk("a2", "a")
        b = chunk("b0", "b")
        base = StaticRetriever(
            [
                SearchResult(a1, 3.0, ()),
                SearchResult(a2, 2.9, ()),
                SearchResult(b, 2.8, ()),
            ]
        )
        reranker = GraphReranker(base, [a1, a2, b])

        results = reranker.search("q", limit=2, per_article_limit=1)
        self.assertEqual(
            [result.chunk.article_id for result in results],
            ["a", "b"],
        )

    def test_empty_and_zero_limits_are_safe(self) -> None:
        a = chunk("a0", "a")
        reranker = GraphReranker(
            StaticRetriever([SearchResult(a, 1.0, ())]),
            [a],
        )

        self.assertEqual(reranker.search("", limit=5), [])
        self.assertEqual(reranker.search("q", limit=0), [])
        self.assertEqual(reranker.search("q", per_article_limit=0), [])

    def test_invalid_configuration_is_rejected(self) -> None:
        base = StaticRetriever([])

        with self.assertRaisesRegex(ValueError, "seed_count"):
            GraphReranker(base, [], seed_count=0)
        with self.assertRaisesRegex(ValueError, "candidate_multiplier"):
            GraphReranker(base, [], candidate_multiplier=0)
        with self.assertRaisesRegex(ValueError, "cannot be negative"):
            GraphReranker(base, [], graph_weight=-0.1)

    def test_ties_are_deterministic(self) -> None:
        a = chunk("a0", "a")
        b = chunk("b0", "b")
        base = StaticRetriever(
            [
                SearchResult(b, 1.0, ()),
                SearchResult(a, 1.0, ()),
            ]
        )
        reranker = GraphReranker(base, [a, b], graph_weight=0.2)

        first = reranker.search("q", limit=2)
        second = reranker.search("q", limit=2)
        self.assertEqual(
            [item.chunk.id for item in first],
            [item.chunk.id for item in second],
        )
        self.assertEqual(
            [item.chunk.id for item in first],
            ["a0", "b0"],
        )
