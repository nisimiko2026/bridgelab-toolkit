from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from typing import Sequence

from core.repository import Repository
from retrieval.chunker import MarkdownChunker
from retrieval.embeddings import EmbeddingVector
from retrieval.evaluation import RetrievalCase, RetrievalEvaluator
from retrieval.hybrid import HybridRetriever, HybridWeights
from retrieval.search import LexicalRetriever, SearchFilters
from retrieval.semantic import SemanticRetriever


class KeywordEmbeddingProvider:
    concepts = ("double", "probability", "sayc", "play")

    @property
    def dimension(self) -> int:
        return len(self.concepts)

    def _embed(self, text: str) -> EmbeddingVector:
        value = text.casefold()
        return tuple(float(value.count(term)) for term in self.concepts)

    def embed_documents(
        self,
        texts: Sequence[str],
    ) -> list[EmbeddingVector]:
        return [self._embed(text) for text in texts]

    def embed_query(self, text: str) -> EmbeddingVector:
        return self._embed(text)


class HybridRetrieverTests(unittest.TestCase):
    def _retrievers(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root = Path(temp.name)

        (root / "negative-double.md").write_text(
            """---
title: Negative Double
category: bidding
subcategory: conventions
difficulty: Intermediate
status: Draft
tags: [competitive]
systems: [SAYC]
aliases: []
acronyms: []
references: []
---
# Negative Double

A negative double is used in competitive bidding.
""",
            encoding="utf-8",
        )
        (root / "restricted-choice.md").write_text(
            """---
title: Restricted Choice
category: play
subcategory: declarer-play
difficulty: Intermediate
status: Draft
tags: [probability]
systems: []
aliases: []
acronyms: []
references: []
---
# Restricted Choice

A probability principle for card play.
""",
            encoding="utf-8",
        )

        chunks = MarkdownChunker(
            target_words=50,
            max_words=200,
        ).chunk_all(Repository(root).build())

        lexical = LexicalRetriever(chunks)
        semantic = SemanticRetriever(chunks, KeywordEmbeddingProvider())
        return lexical, semantic

    def test_hybrid_returns_expected_article(self) -> None:
        lexical, semantic = self._retrievers()
        retriever = HybridRetriever(lexical, semantic)
        results = retriever.search("negative double", limit=5)

        self.assertTrue(results)
        self.assertEqual(results[0].chunk.article_id, "negative-double")

    def test_filters_are_forwarded_to_both_sources(self) -> None:
        lexical, semantic = self._retrievers()
        retriever = HybridRetriever(lexical, semantic)

        results = retriever.search(
            "double",
            filters=SearchFilters(category="bidding", system="sayc"),
        )
        self.assertTrue(results)
        self.assertEqual(results[0].chunk.article_id, "negative-double")

        self.assertEqual(
            retriever.search(
                "double",
                filters=SearchFilters(category="play"),
            ),
            [],
        )

    def test_result_order_is_deterministic(self) -> None:
        lexical, semantic = self._retrievers()
        retriever = HybridRetriever(lexical, semantic)
        first = retriever.search("probability play", limit=10)
        second = retriever.search("probability play", limit=10)

        self.assertEqual(
            [(x.chunk.id, x.score) for x in first],
            [(x.chunk.id, x.score) for x in second],
        )

    def test_weight_can_disable_one_source(self) -> None:
        lexical, semantic = self._retrievers()
        hybrid = HybridRetriever(
            lexical,
            semantic,
            weights=HybridWeights(lexical=1.0, semantic=0.0),
        )
        lexical_only = lexical.search(
            "negative double",
            limit=5,
            per_article_limit=2,
        )

        hybrid_ids = [x.chunk.id for x in hybrid.search("negative double", limit=5)]
        lexical_ids = [x.chunk.id for x in lexical_only]

        self.assertEqual(hybrid_ids, lexical_ids[: len(hybrid_ids)])

    def test_invalid_configuration_is_rejected(self) -> None:
        lexical, semantic = self._retrievers()

        with self.assertRaisesRegex(ValueError, "rrf_k"):
            HybridRetriever(lexical, semantic, rrf_k=0)

        with self.assertRaisesRegex(ValueError, "cannot be negative"):
            HybridRetriever(
                lexical,
                semantic,
                weights=HybridWeights(lexical=-1.0, semantic=1.0),
            )

        with self.assertRaisesRegex(ValueError, "at least one"):
            HybridRetriever(
                lexical,
                semantic,
                weights=HybridWeights(lexical=0.0, semantic=0.0),
            )

    def test_evaluator_accepts_hybrid_retriever(self) -> None:
        lexical, semantic = self._retrievers()
        retriever = HybridRetriever(lexical, semantic)

        _, metrics = RetrievalEvaluator(retriever).evaluate(
            [
                RetrievalCase("negative double", ("negative-double",)),
                RetrievalCase("probability play", ("restricted-choice",)),
            ],
            limit=5,
            per_article_limit=1,
        )

        self.assertEqual(metrics.hit_at_1, 1.0)
        self.assertEqual(metrics.mrr, 1.0)
