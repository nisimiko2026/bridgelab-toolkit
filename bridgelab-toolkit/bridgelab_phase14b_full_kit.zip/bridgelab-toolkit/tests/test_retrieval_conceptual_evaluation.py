from __future__ import annotations

import json
import unittest
from pathlib import Path

from core.repository import Repository
from retrieval.chunker import MarkdownChunker
from retrieval.evaluation import RetrievalEvaluator, load_cases
from retrieval.graph_reranker import GraphReranker
from retrieval.search import LexicalRetriever


class ConceptualRetrievalEvaluationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.toolkit = Path(__file__).resolve().parents[1]
        cls.knowledge = Path(__file__).resolve().parents[2] / "knowledge"

    def test_conceptual_fixture_has_source_provenance(self) -> None:
        fixture = json.loads(
            (
                self.toolkit
                / "data"
                / "retrieval_evaluation_conceptual.json"
            ).read_text(encoding="utf-8")
        )
        provenance = json.loads(
            (
                self.toolkit
                / "data"
                / "retrieval_evaluation_conceptual_sources.json"
            ).read_text(encoding="utf-8")
        )

        self.assertEqual(len(fixture), 12)
        self.assertEqual(len(provenance), 12)
        self.assertEqual(
            [item["query"] for item in fixture],
            [item["query"] for item in provenance],
        )
        self.assertTrue(
            all(item.get("source_basis", "").strip() for item in provenance)
        )

    def test_all_expected_conceptual_articles_exist(self) -> None:
        cases = load_cases(
            self.toolkit
            / "data"
            / "retrieval_evaluation_conceptual.json"
        )
        for case in cases:
            for article_id in case.expected_articles:
                self.assertTrue(
                    (self.knowledge / f"{article_id}.md").exists(),
                    article_id,
                )

    def test_combined_fixture_contains_exact_and_conceptual_cases(self) -> None:
        exact = load_cases(
            self.toolkit / "data" / "retrieval_evaluation.json"
        )
        conceptual = load_cases(
            self.toolkit
            / "data"
            / "retrieval_evaluation_conceptual.json"
        )
        combined = load_cases(
            self.toolkit
            / "data"
            / "retrieval_evaluation_combined.json"
        )

        self.assertEqual(len(exact), 12)
        self.assertEqual(len(conceptual), 12)
        self.assertEqual(len(combined), 24)
        self.assertEqual(
            [case.query for case in combined],
            [case.query for case in exact + conceptual],
        )

    def test_conceptual_fixture_exposes_nontrivial_lexical_baseline(self) -> None:
        chunks = MarkdownChunker(
            target_words=250,
            max_words=800,
        ).chunk_all(Repository(self.knowledge).build())
        cases = load_cases(
            self.toolkit
            / "data"
            / "retrieval_evaluation_conceptual.json"
        )
        lexical = LexicalRetriever(chunks)
        _, metrics = RetrievalEvaluator(lexical).evaluate(
            cases,
            limit=5,
            per_article_limit=1,
        )

        # This fixture is deliberately harder than exact-title/navigation
        # queries. Keep a floor against accidental collapse while allowing
        # future retrieval improvements without changing the test.
        self.assertLess(metrics.hit_at_1, 1.0)
        self.assertGreaterEqual(metrics.hit_at_5, 0.5)

    def test_graph_reranking_does_not_regress_hit_at_5(self) -> None:
        chunks = MarkdownChunker(
            target_words=250,
            max_words=800,
        ).chunk_all(Repository(self.knowledge).build())
        cases = load_cases(
            self.toolkit
            / "data"
            / "retrieval_evaluation_conceptual.json"
        )
        lexical = LexicalRetriever(chunks)
        graph = GraphReranker(lexical, chunks)

        _, lexical_metrics = RetrievalEvaluator(lexical).evaluate(
            cases,
            limit=5,
            per_article_limit=1,
        )
        _, graph_metrics = RetrievalEvaluator(graph).evaluate(
            cases,
            limit=5,
            per_article_limit=1,
        )

        self.assertGreaterEqual(
            graph_metrics.hit_at_5,
            lexical_metrics.hit_at_5,
        )
