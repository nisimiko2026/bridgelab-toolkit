from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from typing import Sequence

from retrieval.benchmark import (
    report_to_dict,
    run_benchmark,
    write_json_report,
    write_markdown_report,
)
from retrieval.embeddings import EmbeddingVector


class KeywordEmbeddingProvider:
    concepts = (
        "negative",
        "double",
        "restricted",
        "choice",
        "vacant",
        "places",
        "sayc",
        "jacoby",
        "opening",
        "leads",
    )

    @property
    def dimension(self) -> int:
        return len(self.concepts)

    def _embed(self, text: str) -> EmbeddingVector:
        value = text.casefold()
        return tuple(float(value.count(term)) for term in self.concepts)

    def embed_documents(
        self,
        texts: Sequence[str],
    ) -> list[EmbeddingVector]:
        return [self._embed(text) for text in texts]

    def embed_query(self, text: str) -> EmbeddingVector:
        return self._embed(text)


class RetrievalBenchmarkTests(unittest.TestCase):
    def _fixture(self, root: Path) -> Path:
        fixture = root / "fixture.json"
        fixture.write_text(
            json.dumps(
                [
                    {
                        "query": "negative double",
                        "expected_articles": ["negative-double"],
                    },
                    {
                        "query": "restricted choice",
                        "expected_articles": ["restricted-choice"],
                    },
                ]
            ),
            encoding="utf-8",
        )
        return fixture

    def _knowledge(self, root: Path) -> Path:
        knowledge = root / "knowledge"
        knowledge.mkdir()

        (knowledge / "negative-double.md").write_text(
            """---
title: Negative Double
description: Test
category: bidding
subcategory: conventions
difficulty: Intermediate
status: Draft
last_updated: 2026-08-27
tags: []
systems: [SAYC]
aliases: []
acronyms: []
references: []
---
# Negative Double

Negative double bidding example.
""",
            encoding="utf-8",
        )
        (knowledge / "restricted-choice.md").write_text(
            """---
title: Restricted Choice
description: Test
category: play
subcategory: declarer-play
difficulty: Intermediate
status: Draft
last_updated: 2026-08-27
tags: []
systems: []
aliases: []
acronyms: []
references: []
---
# Restricted Choice

Restricted choice card play example.
""",
            encoding="utf-8",
        )
        return knowledge

    def test_lexical_only_report(self) -> None:
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root = Path(temp.name)

        report = run_benchmark(
            knowledge_root=self._knowledge(root),
            fixture_path=self._fixture(root),
        )

        self.assertEqual(report.cases, 2)
        self.assertIsNotNone(report.lexical)
        self.assertIsNone(report.semantic)
        self.assertIsNone(report.hybrid)
        self.assertEqual(report.lexical.metrics.hit_at_1, 1.0)

    def test_semantic_and_hybrid_run_when_provider_supplied(self) -> None:
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root = Path(temp.name)

        report = run_benchmark(
            knowledge_root=self._knowledge(root),
            fixture_path=self._fixture(root),
            embedding_provider=KeywordEmbeddingProvider(),
        )

        self.assertIsNotNone(report.semantic)
        self.assertIsNotNone(report.hybrid)
        self.assertEqual(report.semantic.metrics.hit_at_1, 1.0)
        self.assertEqual(report.hybrid.metrics.hit_at_1, 1.0)

    def test_reports_serialize_deterministically(self) -> None:
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root = Path(temp.name)

        report = run_benchmark(
            knowledge_root=self._knowledge(root),
            fixture_path=self._fixture(root),
        )

        data = report_to_dict(report)
        self.assertEqual(data["cases"], 2)
        self.assertIn("lexical", data)

        json_path = root / "report.json"
        md_path = root / "report.md"
        write_json_report(report, json_path)
        write_markdown_report(report, md_path)

        self.assertIn('"lexical"', json_path.read_text(encoding="utf-8"))
        markdown = md_path.read_text(encoding="utf-8")
        self.assertIn("| lexical |", markdown)
        self.assertIn("no embedding provider", markdown)

    def test_live_fixture_preserves_frozen_lexical_baseline(self) -> None:
        toolkit = Path(__file__).resolve().parents[1]
        knowledge = Path(__file__).resolve().parents[2] / "knowledge"

        report = run_benchmark(
            knowledge_root=knowledge,
            fixture_path=toolkit / "data" / "retrieval_evaluation.json",
        )

        self.assertEqual(report.cases, 12)
        self.assertEqual(report.lexical.metrics.hit_at_1, 1.0)
        self.assertEqual(report.lexical.metrics.hit_at_3, 1.0)
        self.assertEqual(report.lexical.metrics.hit_at_5, 1.0)
        self.assertEqual(report.lexical.metrics.mrr, 1.0)
