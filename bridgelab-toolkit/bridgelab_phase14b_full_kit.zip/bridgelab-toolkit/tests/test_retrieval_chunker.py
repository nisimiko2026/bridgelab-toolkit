from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from core.repository import Repository
from retrieval.chunker import MarkdownChunker


class MarkdownChunkerTests(unittest.TestCase):
    def _article(self, markdown: str):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root = Path(temp.name)
        path = root / "topic.md"
        path.write_text(markdown, encoding="utf-8")
        return Repository(root).build()[0]

    def test_excludes_yaml_and_records_heading_structure(self) -> None:
        article = self._article(
            """---
title: Topic
category: play
subcategory: declarer-play
difficulty: Intermediate
status: Draft
tags: [planning]
systems: []
aliases: []
acronyms: []
references: [play/example]
---
# Topic

Intro text.

## Planning

Plan first.

### Detail

Detail text.
"""
        )

        chunks = MarkdownChunker().chunk_article(article)

        self.assertEqual(len(chunks), 1)
        self.assertNotIn("title: Topic", chunks[0].text)
        self.assertEqual(chunks[0].heading_path, ("Topic",))
        self.assertEqual(
            chunks[0].section_paths,
            (
                ("Topic",),
                ("Topic", "Planning"),
                ("Topic", "Planning", "Detail"),
            ),
        )

    def test_chunk_metadata_is_read_only_snapshot(self) -> None:
        article = self._article(
            """---
title: Topic
category: bidding
subcategory: conventions
difficulty: Advanced
status: Draft
tags: [competitive]
systems: [SAYC]
aliases: [Example]
acronyms: [ABC]
references: [bidding/example]
---
# Topic

Text.
"""
        )

        chunk = MarkdownChunker().chunk_article(article)[0]

        self.assertEqual(chunk.title, "Topic")
        self.assertEqual(chunk.category, "bidding")
        self.assertEqual(chunk.tags, ("competitive",))
        self.assertEqual(chunk.systems, ("SAYC",))
        self.assertEqual(chunk.references, ("bidding/example",))
        with self.assertRaises(Exception):
            chunk.title = "Changed"

    def test_chunk_ids_are_deterministic(self) -> None:
        article = self._article(
            """# Topic

Intro.

## First

One.

## Second

Two.
"""
        )
        chunker = MarkdownChunker()

        first = chunker.chunk_article(article)
        second = chunker.chunk_article(article)

        self.assertEqual([x.id for x in first], [x.id for x in second])
        self.assertEqual([x.text for x in first], [x.text for x in second])
        self.assertEqual(len({x.id for x in first}), len(first))

    def test_duplicate_heading_paths_are_preserved(self) -> None:
        article = self._article(
            """# Topic

## Example

First.

## Example

Second.
"""
        )

        chunks = MarkdownChunker().chunk_article(article)

        self.assertEqual(len(chunks), 1)
        self.assertEqual(
            chunks[0].section_paths,
            (("Topic",), ("Topic", "Example"), ("Topic", "Example")),
        )

    def test_markdown_heading_inside_fence_is_not_a_section(self) -> None:
        article = self._article(
            """# Topic

```text
## Not a heading
example
```

## Real

Text.
"""
        )

        chunks = MarkdownChunker().chunk_article(article)

        self.assertEqual(len(chunks), 1)
        self.assertIn("## Not a heading", chunks[0].text)
        self.assertEqual(
            chunks[0].section_paths,
            (("Topic",), ("Topic", "Real")),
        )

    def test_large_section_splits_at_configured_word_limit(self) -> None:
        words = " ".join(f"word{i}" for i in range(130))
        article = self._article(f"# Topic\n\n{words}\n")

        chunks = MarkdownChunker(
            target_words=50,
            max_words=50,
        ).chunk_article(article)

        self.assertGreater(len(chunks), 1)
        self.assertTrue(all(chunk.word_count <= 50 for chunk in chunks))
        self.assertEqual(len({chunk.id for chunk in chunks}), len(chunks))

    def test_id_survives_prose_edit_when_structure_is_unchanged(self) -> None:
        article = self._article(
            """# Topic

Original prose.

## Detail

More prose.
"""
        )
        chunker = MarkdownChunker()
        before = chunker.chunk_article(article)

        article.path.write_text(
            """# Topic

Revised prose with different wording.

## Detail

More revised prose.
""",
            encoding="utf-8",
        )
        after = chunker.chunk_article(article)

        self.assertEqual([x.id for x in before], [x.id for x in after])
        self.assertNotEqual([x.text for x in before], [x.text for x in after])

    def test_chunk_all_sorts_articles_by_canonical_path(self) -> None:
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root = Path(temp.name)
        (root / "z.md").write_text("# Z\n", encoding="utf-8")
        (root / "a.md").write_text("# A\n", encoding="utf-8")
        articles = Repository(root).build()

        chunks = MarkdownChunker().chunk_all(list(reversed(articles)))

        self.assertEqual([x.article_path for x in chunks], ["a.md", "z.md"])

    def test_rejects_tiny_target(self) -> None:
        with self.assertRaisesRegex(ValueError, "at least 50"):
            MarkdownChunker(target_words=49, max_words=800)

    def test_max_words_must_cover_target(self) -> None:
        with self.assertRaisesRegex(ValueError, "at least target_words"):
            MarkdownChunker(target_words=250, max_words=200)


class LiveKnowledgeChunkingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        knowledge = Path(__file__).resolve().parents[2] / "knowledge"
        cls.articles = Repository(knowledge).build()
        cls.chunks = MarkdownChunker(
            target_words=250,
            max_words=800,
        ).chunk_all(cls.articles)

    def test_live_corpus_is_fully_chunked(self) -> None:
        self.assertEqual(len(self.articles), 460)
        self.assertEqual(
            {chunk.article_id for chunk in self.chunks},
            {article.id for article in self.articles},
        )

    def test_live_chunk_ids_are_unique(self) -> None:
        ids = [chunk.id for chunk in self.chunks]
        self.assertEqual(len(ids), len(set(ids)))

    def test_live_chunks_respect_word_limit(self) -> None:
        self.assertTrue(self.chunks)
        self.assertLessEqual(max(chunk.word_count for chunk in self.chunks), 800)

    def test_live_chunking_is_deterministic(self) -> None:
        second = MarkdownChunker(
            target_words=250,
            max_words=800,
        ).chunk_all(self.articles)
        self.assertEqual(
            [(x.id, x.text) for x in self.chunks],
            [(x.id, x.text) for x in second],
        )
