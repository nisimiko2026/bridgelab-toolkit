from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from core.repository import Repository
from retrieval.chunker import MarkdownChunker
from retrieval.evaluation import (
    RetrievalCase,
    RetrievalEvaluator,
    load_cases,
)
from retrieval.search import LexicalRetriever


class RetrievalEvaluationUnitTests(unittest.TestCase):
    def _retriever(self) -> LexicalRetriever:
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root = Path(temp.name)
        (root / "alpha.md").write_text(
            "# Alpha\n\nAlpha topic and bidding example.\n",
            encoding="utf-8",
        )
        (root / "beta.md").write_text(
            "# Beta\n\nBeta topic and card play example.\n",
            encoding="utf-8",
        )
        chunks = MarkdownChunker(
            target_words=50,
            max_words=200,
        ).chunk_all(Repository(root).build())
        return LexicalRetriever(chunks)

    def test_metrics_are_computed_from_first_relevant_rank(self) -> None:
        evaluator = RetrievalEvaluator(self._retriever())
        results, metrics = evaluator.evaluate(
            [
                RetrievalCase("alpha", ("alpha",)),
                RetrievalCase("beta", ("beta",)),
            ],
            limit=5,
        )

        self.assertEqual([x.first_relevant_rank for x in results], [1, 1])
        self.assertEqual(metrics.cases, 2)
        self.assertEqual(metrics.hit_at_1, 1.0)
        self.assertEqual(metrics.hit_at_3, 1.0)
        self.assertEqual(metrics.hit_at_5, 1.0)
        self.assertEqual(metrics.mrr, 1.0)

    def test_empty_case_set_returns_zero_metrics(self) -> None:
        _, metrics = RetrievalEvaluator(self._retriever()).evaluate([])
        self.assertEqual(metrics.cases, 0)
        self.assertEqual(metrics.mrr, 0.0)

    def test_fixture_loader_validates_schema(self) -> None:
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        path = Path(temp.name) / "fixture.json"
        path.write_text(
            json.dumps(
                [
                    {
                        "query": "alpha",
                        "expected_articles": ["alpha"],
                        "filters": {"category": "bidding"},
                    }
                ]
            ),
            encoding="utf-8",
        )
        cases = load_cases(path)
        self.assertEqual(cases[0].query, "alpha")
        self.assertEqual(cases[0].expected_articles, ("alpha",))
        self.assertEqual(cases[0].filters.category, "bidding")

    def test_fixture_loader_rejects_unknown_filter(self) -> None:
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        path = Path(temp.name) / "fixture.json"
        path.write_text(
            json.dumps(
                [
                    {
                        "query": "alpha",
                        "expected_articles": ["alpha"],
                        "filters": {"unknown": "value"},
                    }
                ]
            ),
            encoding="utf-8",
        )
        with self.assertRaisesRegex(ValueError, "unknown filters"):
            load_cases(path)


class LiveRetrievalEvaluationHarnessTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        toolkit = Path(__file__).resolve().parents[1]
        knowledge = Path(__file__).resolve().parents[2] / "knowledge"
        fixture = toolkit / "data" / "retrieval_evaluation.json"

        articles = Repository(knowledge).build()
        chunks = MarkdownChunker(
            target_words=250,
            max_words=800,
        ).chunk_all(articles)
        retriever = LexicalRetriever(chunks)
        cls.cases = load_cases(fixture)
        cls.results, cls.metrics = RetrievalEvaluator(retriever).evaluate(
            cls.cases,
            limit=5,
            per_article_limit=1,
        )

    def test_fixture_has_broad_minimum_coverage(self) -> None:
        self.assertGreaterEqual(len(self.cases), 12)

    def test_live_baseline_hit_at_one_is_frozen(self) -> None:
        self.assertEqual(self.metrics.hit_at_1, 1.0)

    def test_live_baseline_hit_at_five_is_frozen(self) -> None:
        self.assertEqual(self.metrics.hit_at_5, 1.0)

    def test_live_baseline_mrr_is_frozen(self) -> None:
        self.assertEqual(self.metrics.mrr, 1.0)
