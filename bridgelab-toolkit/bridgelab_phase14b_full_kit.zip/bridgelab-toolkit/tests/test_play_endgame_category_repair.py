from __future__ import annotations

from tests._ansi import strip_ansi

import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from typer.testing import CliRunner

from main import app
from metadata.play_endgame_category_repair import (
    REVIEWED_ARTICLE,
    apply_play_endgame_category_report,
    build_play_endgame_category_report,
)


def article_text(*, category: str = "Card Play – Defence", newline: str = "\n") -> str:
    return (
        f"---{newline}"
        f"title: Endgame Defence{newline}"
        f"description: Reviewed temporary fixture with exact byte preservation.{newline}"
        f"category: {category}{newline}"
        f"subcategory: defence{newline}"
        f"difficulty: Advanced to Expert{newline}"
        f"tags: {newline}  - card play – defence{newline}  - endplay{newline}"
        f"systems: []{newline}aliases: []{newline}acronyms: []{newline}"
        f"references: {newline}  - play/defence/index-defence{newline}"
        f"last_updated: 2026-08-16{newline}status: Draft{newline}"
        f"unknown_field: preserve exactly{newline}"
        f"---{newline}# Endgame Defence{newline}{newline}"
        f"Body  with  exact spacing.{newline}"
    )


class PlayEndgameCategoryRepairTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary_directory = tempfile.TemporaryDirectory()
        self.base = Path(self.temporary_directory.name)
        self.root = self.base / "knowledge"
        self.root.mkdir()
        self.backup = self.base / "explicit-backup"
        self.runner = CliRunner()

    def tearDown(self) -> None:
        self.temporary_directory.cleanup()

    def write(self, relative: str, content: str) -> Path:
        path = self.root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content.encode("utf-8"))
        return path

    def target(self, *, newline: str = "\n") -> Path:
        return self.write(REVIEWED_ARTICLE, article_text(newline=newline))

    def invoke(self, *arguments: str):
        return self.runner.invoke(
            app,
            ["repair-play-endgame-category", "--root", str(self.root), *arguments],
        )

    def test_default_dry_run_selects_only_target_and_writes_nothing(self) -> None:
        target = self.target(newline="\r\n")
        other_play = self.write("play/defence/other.md", article_text())
        bidding = self.write("bidding/other.md", article_text())
        before = {path: path.read_bytes() for path in (target, other_play, bidding)}

        result = self.invoke()

        self.assertEqual(result.exit_code, 0, strip_ansi(result.output))
        self.assertIn(REVIEWED_ARTICLE, strip_ansi(result.output))
        self.assertIn("Files selected      : 1", strip_ansi(result.output))
        self.assertIn("Files to update     : 1", strip_ansi(result.output))
        self.assertIn("Tag changes         : 0", strip_ansi(result.output))
        self.assertIn("Subcategory changes : 0", strip_ansi(result.output))
        self.assertNotIn("play/defence/other.md", strip_ansi(result.output))
        self.assertNotIn("bidding/other.md", strip_ansi(result.output))
        self.assertEqual({path: path.read_bytes() for path in before}, before)
        self.assertFalse(self.backup.exists())

    def test_apply_changes_only_category_and_backup_is_exact(self) -> None:
        target = self.target(newline="\r\n")
        original = target.read_bytes()

        result = self.invoke("--apply", "--backup", str(self.backup))

        self.assertEqual(result.exit_code, 0, strip_ansi(result.output))
        expected = original.replace(
            b"category: Card Play \xe2\x80\x93 Defence\r\n",
            b"category: play\r\n",
            1,
        )
        self.assertEqual(target.read_bytes(), expected)
        self.assertEqual((self.backup / REVIEWED_ARTICLE).read_bytes(), original)
        self.assertIn(b"  - card play \xe2\x80\x93 defence\r\n", expected)
        self.assertNotIn(b"  - play\r\n", expected)
        self.assertIn(b"subcategory: defence\r\n", expected)
        self.assertIn(b"last_updated: 2026-08-16\r\n", expected)
        self.assertIn(b"unknown_field: preserve exactly\r\n", expected)
        self.assertIn(b"Body  with  exact spacing.\r\n", expected)

    def test_apply_requires_explicit_backup(self) -> None:
        target = self.target()
        original = target.read_bytes()

        result = self.invoke("--apply")

        self.assertNotEqual(result.exit_code, 0)
        self.assertIn("--backup is required", strip_ansi(result.output))
        self.assertEqual(target.read_bytes(), original)

    def test_stale_precondition_aborts_before_backup_or_write(self) -> None:
        target = self.target()
        report = build_play_endgame_category_report(self.root)
        target.write_bytes(target.read_bytes() + b"external change\n")
        stale = target.read_bytes()

        with self.assertRaisesRegex(RuntimeError, "precondition mismatch"):
            apply_play_endgame_category_report(report, self.root, self.backup)

        self.assertEqual(target.read_bytes(), stale)
        self.assertFalse(self.backup.exists())

    def test_backup_overwrite_refusal_and_atomic_failure_are_safe(self) -> None:
        target = self.target()
        report = build_play_endgame_category_report(self.root)
        original = target.read_bytes()
        self.backup.mkdir()
        with self.assertRaisesRegex(RuntimeError, "already exists"):
            apply_play_endgame_category_report(report, self.root, self.backup)
        self.assertEqual(target.read_bytes(), original)

        self.backup.rmdir()
        with patch(
            "metadata.play_endgame_category_repair._atomic_write",
            side_effect=OSError("replace failed"),
        ):
            with self.assertRaisesRegex(OSError, "replace failed"):
                apply_play_endgame_category_report(report, self.root, self.backup)
        self.assertEqual(target.read_bytes(), original)
        self.assertEqual((self.backup / REVIEWED_ARTICLE).read_bytes(), original)

    def test_idempotence_explicit_root_and_cli_help(self) -> None:
        target = self.target()
        first = self.invoke("--apply", "--backup", str(self.backup))
        after = target.read_bytes()
        second_report = build_play_endgame_category_report(self.root)
        second = self.invoke("--apply")
        help_result = self.runner.invoke(app, ["repair-play-endgame-category", "--help"])

        self.assertEqual(first.exit_code, 0, first.output)
        self.assertEqual(second_report.actions, ())
        self.assertEqual(second.exit_code, 0, second.output)
        self.assertIn("Files to update     : 0", second.output)
        self.assertIn("Files to back up    : 0", second.output)
        self.assertEqual(target.read_bytes(), after)
        self.assertEqual(help_result.exit_code, 0, strip_ansi(help_result.output))
        self.assertIn("--root", strip_ansi(help_result.output))
        self.assertIn("--backup", strip_ansi(help_result.output))
        self.assertIn("--apply", strip_ansi(help_result.output))


if __name__ == "__main__":
    unittest.main()
