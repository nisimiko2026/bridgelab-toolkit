from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from core.repository import Repository
from retrieval.chunker import MarkdownChunker
from retrieval.search import (
    LexicalRetriever,
    SearchFilters,
    normalize_text,
    tokenize,
)


class LexicalRetrieverTests(unittest.TestCase):
    def _retriever(self) -> LexicalRetriever:
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root = Path(temp.name)

        (root / "negative-double.md").write_text(
            """---
title: Negative Double
category: bidding
subcategory: conventions
difficulty: Intermediate
status: Draft
tags: [double, competitive]
systems: [SAYC]
aliases: [Negative Doubles]
acronyms: []
references: []
---
# Negative Double

A negative double is used in competitive auctions.

## Requirements

Responder shows values and unbid suits.
""",
            encoding="utf-8",
        )
        (root / "restricted-choice.md").write_text(
            """---
title: Restricted Choice
category: play
subcategory: declarer-play
difficulty: Intermediate
status: Draft
tags: [probability]
systems: []
aliases: []
acronyms: [RC]
references: []
---
# Restricted Choice

Restricted choice is a card-play probability principle.
""",
            encoding="utf-8",
        )
        articles = Repository(root).build()
        chunks = MarkdownChunker(target_words=50, max_words=200).chunk_all(articles)
        return LexicalRetriever(chunks)

    def test_exact_title_query_ranks_matching_article_first(self) -> None:
        results = self._retriever().search("negative double", limit=5)
        self.assertTrue(results)
        self.assertEqual(results[0].chunk.article_id, "negative-double")
        self.assertGreater(results[0].score, 0)

    def test_acronym_is_searchable(self) -> None:
        results = self._retriever().search("RC")
        self.assertEqual(results[0].chunk.article_id, "restricted-choice")

    def test_metadata_filter_is_enforced(self) -> None:
        retriever = self._retriever()
        self.assertEqual(
            retriever.search(
                "double",
                filters=SearchFilters(category="play"),
            ),
            [],
        )
        results = retriever.search(
            "double",
            filters=SearchFilters(category="bidding", system="sayc"),
        )
        self.assertTrue(results)
        self.assertEqual(results[0].chunk.article_id, "negative-double")

    def test_results_are_deterministic(self) -> None:
        retriever = self._retriever()
        first = retriever.search("probability principle", limit=10)
        second = retriever.search("probability principle", limit=10)
        self.assertEqual(
            [(x.chunk.id, x.score) for x in first],
            [(x.chunk.id, x.score) for x in second],
        )

    def test_per_article_limit_controls_result_diversity(self) -> None:
        retriever = self._retriever()
        results = retriever.search(
            "negative double",
            limit=10,
            per_article_limit=1,
        )
        counts = {}
        for result in results:
            counts[result.chunk.article_id] = counts.get(result.chunk.article_id, 0) + 1
        self.assertTrue(all(value <= 1 for value in counts.values()))

    def test_empty_or_zero_limit_query_returns_empty(self) -> None:
        retriever = self._retriever()
        self.assertEqual(retriever.search(""), [])
        self.assertEqual(retriever.search("double", limit=0), [])
        self.assertEqual(
            retriever.search("double", per_article_limit=0),
            [],
        )

    def test_normalization_is_case_insensitive_and_unifies_no_trump(self) -> None:
        self.assertEqual(normalize_text("No Trump"), "notrump")
        self.assertEqual(tokenize("SAYC"), ("sayc",))


class LiveRetrievalEvaluationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        knowledge = Path(__file__).resolve().parents[2] / "knowledge"
        articles = Repository(knowledge).build()
        chunks = MarkdownChunker(
            target_words=250,
            max_words=800,
        ).chunk_all(articles)
        cls.retriever = LexicalRetriever(chunks)

    def test_exact_topic_queries_hit_expected_article_at_rank_one(self) -> None:
        cases = (
            ("negative double", "bidding/conventions/doubles/negative-double"),
            (
                "restricted choice",
                "play/declarer-play/general-techniques/restricted-choice",
            ),
            ("vacant places", "play/counting/vacant-places"),
            ("SAYC", "bidding/systems/sayc"),
            ("Jacoby 2NT", "bidding/conventions/responses/jacoby-notrump"),
            (
                "opening leads",
                "play/defence/opening-leads/opening-leads-index",
            ),
        )

        for query, expected in cases:
            with self.subTest(query=query):
                results = self.retriever.search(query, limit=5)
                self.assertTrue(results)
                self.assertEqual(results[0].chunk.article_id, expected)

    def test_live_results_are_article_diverse_by_default(self) -> None:
        results = self.retriever.search("restricted choice", limit=10)
        counts = {}
        for result in results:
            counts[result.chunk.article_id] = counts.get(result.chunk.article_id, 0) + 1
        self.assertTrue(all(value <= 2 for value in counts.values()))
