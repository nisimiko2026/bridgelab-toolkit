from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from typing import Sequence

from core.repository import Repository
from retrieval.chunker import MarkdownChunker
from retrieval.embeddings import EmbeddingVector
from retrieval.evaluation import RetrievalCase, RetrievalEvaluator
from retrieval.search import SearchFilters
from retrieval.semantic import SemanticRetriever, chunk_embedding_text


class KeywordEmbeddingProvider:
    """
    Deterministic test-only embedding provider.

    Dimensions correspond to fixed semantic concepts so tests exercise the
    retriever contract without external models or network calls.
    """

    concepts = ("double", "probability", "sayc", "play")

    @property
    def dimension(self) -> int:
        return len(self.concepts)

    def _embed(self, text: str) -> EmbeddingVector:
        value = text.casefold()
        return tuple(float(value.count(term)) for term in self.concepts)

    def embed_documents(
        self,
        texts: Sequence[str],
    ) -> list[EmbeddingVector]:
        return [self._embed(text) for text in texts]

    def embed_query(self, text: str) -> EmbeddingVector:
        return self._embed(text)


class BadCountProvider(KeywordEmbeddingProvider):
    def embed_documents(
        self,
        texts: Sequence[str],
    ) -> list[EmbeddingVector]:
        return []


class BadDimensionProvider(KeywordEmbeddingProvider):
    def embed_query(self, text: str) -> EmbeddingVector:
        return (1.0, 2.0)


class SemanticRetrieverTests(unittest.TestCase):
    def _chunks(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root = Path(temp.name)

        (root / "negative-double.md").write_text(
            """---
title: Negative Double
category: bidding
subcategory: conventions
difficulty: Intermediate
status: Draft
tags: [competitive]
systems: [SAYC]
aliases: []
acronyms: []
references: []
---
# Negative Double

A negative double is used in competitive bidding.
""",
            encoding="utf-8",
        )
        (root / "restricted-choice.md").write_text(
            """---
title: Restricted Choice
category: play
subcategory: declarer-play
difficulty: Intermediate
status: Draft
tags: [probability]
systems: []
aliases: []
acronyms: []
references: []
---
# Restricted Choice

A probability principle for card play.
""",
            encoding="utf-8",
        )

        articles = Repository(root).build()
        return MarkdownChunker(
            target_words=50,
            max_words=200,
        ).chunk_all(articles)

    def test_semantic_query_ranks_expected_concept_first(self) -> None:
        retriever = SemanticRetriever(
            self._chunks(),
            KeywordEmbeddingProvider(),
        )
        results = retriever.search("probability play", limit=5)
        self.assertTrue(results)
        self.assertEqual(results[0].chunk.article_id, "restricted-choice")

    def test_metadata_filters_are_enforced(self) -> None:
        retriever = SemanticRetriever(
            self._chunks(),
            KeywordEmbeddingProvider(),
        )
        results = retriever.search(
            "double",
            filters=SearchFilters(category="bidding", system="sayc"),
        )
        self.assertTrue(results)
        self.assertEqual(results[0].chunk.article_id, "negative-double")

        self.assertEqual(
            retriever.search(
                "double",
                filters=SearchFilters(category="play"),
            ),
            [],
        )

    def test_empty_query_and_zero_limits_return_empty(self) -> None:
        retriever = SemanticRetriever(
            self._chunks(),
            KeywordEmbeddingProvider(),
        )
        self.assertEqual(retriever.search(""), [])
        self.assertEqual(retriever.search("double", limit=0), [])
        self.assertEqual(
            retriever.search("double", per_article_limit=0),
            [],
        )

    def test_results_are_deterministic(self) -> None:
        retriever = SemanticRetriever(
            self._chunks(),
            KeywordEmbeddingProvider(),
        )
        first = retriever.search("double", limit=10)
        second = retriever.search("double", limit=10)
        self.assertEqual(
            [(item.chunk.id, item.score) for item in first],
            [(item.chunk.id, item.score) for item in second],
        )

    def test_article_diversity_limit_is_respected(self) -> None:
        retriever = SemanticRetriever(
            self._chunks(),
            KeywordEmbeddingProvider(),
        )
        results = retriever.search(
            "double probability play",
            limit=10,
            per_article_limit=1,
        )
        counts = {}
        for result in results:
            counts[result.chunk.article_id] = (
                counts.get(result.chunk.article_id, 0) + 1
            )
        self.assertTrue(all(value <= 1 for value in counts.values()))

    def test_document_vector_count_mismatch_is_rejected(self) -> None:
        with self.assertRaisesRegex(ValueError, "different number of vectors"):
            SemanticRetriever(
                self._chunks(),
                BadCountProvider(),
            )

    def test_query_dimension_mismatch_is_rejected(self) -> None:
        retriever = SemanticRetriever(
            self._chunks(),
            BadDimensionProvider(),
        )
        with self.assertRaisesRegex(ValueError, "dimension mismatch"):
            retriever.search("double")

    def test_embedding_text_contains_metadata_and_body(self) -> None:
        chunk = self._chunks()[0]
        text = chunk_embedding_text(chunk)
        self.assertIn(chunk.title, text)
        self.assertIn(chunk.category, text)
        self.assertIn(chunk.text, text)

    def test_evaluator_accepts_semantic_retriever(self) -> None:
        retriever = SemanticRetriever(
            self._chunks(),
            KeywordEmbeddingProvider(),
        )
        _, metrics = RetrievalEvaluator(retriever).evaluate(
            [
                RetrievalCase(
                    "double",
                    ("negative-double",),
                ),
                RetrievalCase(
                    "probability play",
                    ("restricted-choice",),
                ),
            ],
            limit=5,
            per_article_limit=1,
        )
        self.assertEqual(metrics.hit_at_1, 1.0)
        self.assertEqual(metrics.mrr, 1.0)
