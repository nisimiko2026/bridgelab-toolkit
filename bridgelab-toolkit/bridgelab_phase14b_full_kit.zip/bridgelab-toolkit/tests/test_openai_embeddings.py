from __future__ import annotations

import unittest
from dataclasses import dataclass

from retrieval.openai_embeddings import OpenAIEmbeddingProvider


@dataclass
class FakeEmbedding:
    index: int
    embedding: list[float]


@dataclass
class FakeResponse:
    data: list[FakeEmbedding]


class FakeEmbeddingsAPI:
    def __init__(self, dimension: int) -> None:
        self.dimension = dimension
        self.calls = []

    def create(self, **kwargs):
        self.calls.append(kwargs)
        values = kwargs["input"]
        data = [
            FakeEmbedding(
                index=index,
                embedding=[float(index + 1)] * self.dimension,
            )
            for index, _ in enumerate(values)
        ]
        return FakeResponse(data=list(reversed(data)))


class FakeClient:
    def __init__(self, dimension: int) -> None:
        self.embeddings = FakeEmbeddingsAPI(dimension)


class BadCountEmbeddingsAPI(FakeEmbeddingsAPI):
    def create(self, **kwargs):
        return FakeResponse(data=[])


class BadIndexEmbeddingsAPI(FakeEmbeddingsAPI):
    def create(self, **kwargs):
        return FakeResponse(
            data=[
                FakeEmbedding(index=2, embedding=[1.0] * self.dimension),
            ]
        )


class BadDimensionEmbeddingsAPI(FakeEmbeddingsAPI):
    def create(self, **kwargs):
        return FakeResponse(
            data=[
                FakeEmbedding(index=0, embedding=[1.0]),
            ]
        )


class OpenAIEmbeddingProviderTests(unittest.TestCase):
    def test_documents_are_batched_and_returned_in_input_order(self) -> None:
        client = FakeClient(3)
        provider = OpenAIEmbeddingProvider(
            model="text-embedding-3-small",
            dimension=3,
            batch_size=2,
            client=client,
        )

        vectors = provider.embed_documents(["a", "b", "c"])

        self.assertEqual(
            vectors,
            [
                (1.0, 1.0, 1.0),
                (2.0, 2.0, 2.0),
                (1.0, 1.0, 1.0),
            ],
        )
        self.assertEqual(len(client.embeddings.calls), 2)
        self.assertEqual(
            client.embeddings.calls[0],
            {
                "model": "text-embedding-3-small",
                "input": ["a", "b"],
                "dimensions": 3,
                "encoding_format": "float",
            },
        )

    def test_query_uses_same_provider_contract(self) -> None:
        client = FakeClient(4)
        provider = OpenAIEmbeddingProvider(
            dimension=4,
            client=client,
        )

        self.assertEqual(
            provider.embed_query("bridge query"),
            (1.0, 1.0, 1.0, 1.0),
        )

    def test_empty_document_list_does_not_call_api(self) -> None:
        client = FakeClient(3)
        provider = OpenAIEmbeddingProvider(
            dimension=3,
            client=client,
        )

        self.assertEqual(provider.embed_documents([]), [])
        self.assertEqual(client.embeddings.calls, [])

    def test_empty_query_is_rejected(self) -> None:
        provider = OpenAIEmbeddingProvider(
            dimension=3,
            client=FakeClient(3),
        )
        with self.assertRaisesRegex(ValueError, "non-empty"):
            provider.embed_query("   ")

    def test_invalid_configuration_is_rejected(self) -> None:
        with self.assertRaisesRegex(ValueError, "model"):
            OpenAIEmbeddingProvider(model="", client=FakeClient(3))
        with self.assertRaisesRegex(ValueError, "dimension"):
            OpenAIEmbeddingProvider(dimension=0, client=FakeClient(3))
        with self.assertRaisesRegex(ValueError, "batch_size"):
            OpenAIEmbeddingProvider(batch_size=0, client=FakeClient(3))

    def test_response_count_mismatch_is_rejected(self) -> None:
        client = FakeClient(3)
        client.embeddings = BadCountEmbeddingsAPI(3)
        provider = OpenAIEmbeddingProvider(
            dimension=3,
            client=client,
        )
        with self.assertRaisesRegex(ValueError, "count"):
            provider.embed_documents(["a"])

    def test_non_contiguous_response_indices_are_rejected(self) -> None:
        client = FakeClient(3)
        client.embeddings = BadIndexEmbeddingsAPI(3)
        provider = OpenAIEmbeddingProvider(
            dimension=3,
            client=client,
        )
        with self.assertRaisesRegex(ValueError, "indices"):
            provider.embed_documents(["a"])

    def test_vector_dimension_mismatch_is_rejected(self) -> None:
        client = FakeClient(3)
        client.embeddings = BadDimensionEmbeddingsAPI(3)
        provider = OpenAIEmbeddingProvider(
            dimension=3,
            client=client,
        )
        with self.assertRaisesRegex(ValueError, "dimension mismatch"):
            provider.embed_documents(["a"])
