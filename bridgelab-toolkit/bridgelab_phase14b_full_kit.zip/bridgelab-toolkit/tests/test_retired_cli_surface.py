from __future__ import annotations

import re
import unittest

from typer.testing import CliRunner

from main import app
from tests._ansi import strip_ansi


RETIRED_COMMANDS = ('repair-bidding-categories', 'repair-blue-club-status', 'repair-category-normalization-batch1', 'repair-category-normalization-batch2', 'repair-category-normalization-batch3-1', 'repair-category-normalization-batch3-2', 'repair-category-normalization-batch3-3a', 'repair-category-normalization-batch3-3aa', 'repair-category-normalization-batch3-3ab', 'repair-category-normalization-batch3-3ac', 'repair-category-normalization-batch3-3ad', 'repair-category-normalization-batch3-3ae', 'repair-category-normalization-batch3-3af', 'repair-category-normalization-batch3-3b', 'repair-category-normalization-batch3-3c', 'repair-category-normalization-batch3-3d', 'repair-category-normalization-batch3-3e', 'repair-category-normalization-batch3-3f', 'repair-category-normalization-batch3-3g', 'repair-category-normalization-batch3-3h', 'repair-category-normalization-batch3-3i', 'repair-category-normalization-batch3-3j', 'repair-category-normalization-batch3-3k', 'repair-category-normalization-batch3-3l', 'repair-category-normalization-batch3-3m', 'repair-category-normalization-batch3-3n', 'repair-category-normalization-batch3-3o', 'repair-category-normalization-batch3-3p', 'repair-category-normalization-batch3-3q', 'repair-category-normalization-batch3-3r', 'repair-category-normalization-batch3-3s1', 'repair-category-normalization-batch3-3s2', 'repair-category-normalization-batch3-3t', 'repair-category-normalization-batch3-3u', 'repair-category-normalization-batch3-3v', 'repair-category-normalization-batch3-3w', 'repair-category-normalization-batch3-3x', 'repair-category-normalization-batch3-3y', 'repair-category-normalization-batch3-3z', 'repair-filenames', 'repair-play-counting-category', 'repair-play-coups-categories', 'repair-play-declarer-deception-categories', 'repair-play-declarer-notrump-categories', 'repair-play-declarer-squeezes-categories', 'repair-play-defence-opening-leads-categories', 'repair-play-defence-planning-category', 'repair-play-defence-techniques-categories', 'repair-play-endgame-category', 'repair-play-endplays-categories', 'repair-play-finesses-categories', 'repair-play-general-techniques-categories', 'repair-play-principles-categories', 'repair-play-probability-category', 'repair-play-signaling-category', 'repair-play-trump-play-categories', 'repair-principles', 'repair-spelling', 'repair-systems', 'repair-title-h1-case-normalization-batch1', 'repair-title-h1-content-repair-batch3', 'repair-title-h1-metadata-case-repair-batch7', 'repair-title-h1-parenthetical-aliases-batch9', 'repair-title-h1-punctuation-normalization-batch2')
RETAINED_COMMANDS = (
    "validate",
    "category-impact",
    "repair-plan",
    "repair-apply",
    "sentinel-cleanup",
)


class RetiredCliSurfaceTests(unittest.TestCase):
    def test_retired_repair_commands_are_not_public_cli_commands(self) -> None:
        result = CliRunner().invoke(app, ["--help"])
        self.assertEqual(result.exit_code, 0, result.output)
        output = strip_ansi(result.output)

        for command in RETIRED_COMMANDS:
            with self.subTest(command=command):
                self.assertIsNone(
                    re.search(rf"(?:^|\n).*?\b{re.escape(command)}\b", output)
                )

    def test_dependency_sensitive_and_permanent_commands_remain(self) -> None:
        result = CliRunner().invoke(app, ["--help"])
        self.assertEqual(result.exit_code, 0, result.output)
        output = strip_ansi(result.output)

        for command in RETAINED_COMMANDS:
            with self.subTest(command=command):
                self.assertIn(command, output)


if __name__ == "__main__":
    unittest.main()
