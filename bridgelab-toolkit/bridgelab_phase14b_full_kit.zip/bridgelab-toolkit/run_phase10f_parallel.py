from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
import json, os
from bridge.milestone_checkpoint import run_checkpoint, merge_checkpoint_files, save_checkpoint

OUT=Path('/mnt/data/bridgelab_phase10f/checkpoints')
OUT.mkdir(parents=True, exist_ok=True)
START=1
TOTAL=100_000
CHUNK=1_000

def one(seed):
    p=OUT/f'chunk_{seed:06d}_{seed+CHUNK-1:06d}.json'
    if p.exists():
        return str(p)
    run_checkpoint(start_seed=seed,count=CHUNK,path=p)
    return str(p)

seeds=list(range(START, START+TOTAL, CHUNK))
paths=[]
workers=min(12, os.cpu_count() or 4)
print('workers',workers,'chunks',len(seeds),flush=True)
with ProcessPoolExecutor(max_workers=workers) as ex:
    futs={ex.submit(one,s):s for s in seeds}
    for i,f in enumerate(as_completed(futs),1):
        p=f.result(); paths.append(p)
        if i%10==0: print('done',i,flush=True)

paths=tuple(str(OUT/f'chunk_{s:06d}_{s+CHUNK-1:06d}.json') for s in seeds)
summary=merge_checkpoint_files(paths,start_seed=START,total_count=TOTAL)
final=Path('/mnt/data/bridgelab_phase10f/phase10f_100k_summary.json')
save_checkpoint(summary,final)
print(json.dumps({
 'start_seed':summary.start_seed,'deal_count':summary.deal_count,
 'total_positions':summary.total_positions,'total_actions':summary.total_actions,
 'total_abstentions':summary.total_abstentions,
 'results':[{'scenario_id':r.scenario_id,'positions':r.positions_reached,'actions':r.production_actions,'abstentions':r.abstentions,'rule_counts':dict(r.rule_counts)} for r in summary.results]
},sort_keys=True),flush=True)
