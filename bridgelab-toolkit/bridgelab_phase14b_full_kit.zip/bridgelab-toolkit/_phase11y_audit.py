
import collections,json
from pathlib import Path
from bridge import run_sayc_coverage_benchmark, Suit, Seat, evaluate_hand

report=run_sayc_coverage_benchmark(start_seed=1,count=10000)
targets=[case for case in report.batch.cases
         if case.result.stop_reason.value=="no-recommendation"
         and case.result.final_auction=="1D P 1H P 2C P"]

hcp=collections.Counter(); hearts=collections.Counter(); clubs=collections.Counter()
diamonds=collections.Counter(); spades=collections.Counter(); fam=collections.Counter()
balanced=0; details=[]
for case in targets:
    ev=evaluate_hand(case.deal.hand(Seat.SOUTH))
    S=ev.length(Suit.SPADES); H=ev.length(Suit.HEARTS)
    D=ev.length(Suit.DIAMONDS); C=ev.length(Suit.CLUBS)
    x={"seed":case.deal.seed,"hcp":ev.hcp,"S":S,"H":H,"D":D,"C":C,"balanced":ev.is_balanced}
    hcp[ev.hcp]+=1; hearts[H]+=1; clubs[C]+=1; diamonds[D]+=1; spades[S]+=1
    balanced += int(ev.is_balanced)
    # disjoint shape-only diagnostic buckets, not prescriptions
    if H>=6:
        cat="rebid_hearts_6plus"
    elif D>=3:
        cat="diamond_preference_3plus_no6H"
    elif C>=4:
        cat="club_support_4plus_no6H_lt3D"
    elif S>=4:
        cat="spade_second_suit_4plus_no6H_lt3D_lt4C"
    elif ev.is_balanced:
        cat="balanced_other"
    else:
        cat="other"
    fam[cat]+=1; x["family"]=cat; details.append(x)

data={"phase":"11Y","sample":{"start_seed":1,"count":10000,"target_count":len(targets)},
      "hcp_distribution":dict(sorted(hcp.items())),
      "heart_length_distribution":dict(sorted(hearts.items())),
      "diamond_length_distribution":dict(sorted(diamonds.items())),
      "club_length_distribution":dict(sorted(clubs.items())),
      "spade_length_distribution":dict(sorted(spades.items())),
      "balanced_count":balanced,
      "diagnostic_families":dict(fam),
      "details":details}
Path("/mnt/data/bridgelab_phase11y_1d1h2c_responder_audit.json").write_text(json.dumps(data,indent=2),encoding="utf-8")
print(json.dumps({k:v for k,v in data.items() if k!="details"},indent=2))
